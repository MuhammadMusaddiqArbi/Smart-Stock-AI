# SmartStock AI: An Intelligent Inventory Replenishment Agent

AL-2002 Artificial Intelligence Lab, FAST NUCES

SmartStock AI manages a small supply chain: **1 supplier -> 1 warehouse -> 3 stores, 5 products, 90 days**.
Every day the agent must decide **(1) what to order from the supplier** and **(2) how to split the warehouse stock
across the stores** (one truck, limited capacity), so that ordering + holding + stock-out (lost-sale) costs are minimal.

## Architecture (two-stage agent)

```
              forecast (calendar-aware)            simulator state
                      |                                   |
          +-----------v-----------+                       |
          |  RuleEngine (IF-THEN) |  LOW_STOCK / UPCOMING_SALE / PERIODIC / INITIAL
          +-----------+-----------+  -> decides WHEN to re-plan
                      |
          +-----------v-----------+
 Stage 1  |  A* planner           |  -> decides WHAT to order (per product, 14-day rolling horizon)
          +-----------+-----------+
                      |  supplier orders
          +-----------v-----------+
 Stage 2  |  Genetic Algorithm    |  -> decides WHERE the warehouse stock goes (store x product)
          +-----------+-----------+
                      |  (orders, allocation)
          +-----------v-----------+
          |  InventoryEnv         |  single source of truth for all cost accounting
          +-----------------------+
```

Policies compared (`src/policies.py`):

| Policy | Ordering | Allocation |
|---|---|---|
| `ReorderPointPolicy` (baseline) | (s, S) rule | Proportional |
| `RulesAStarEqualPolicy` (ablation 1) | Rules + A* | Equal |
| `RulesAStarPropPolicy` (ablation 2) | Rules + A* | Proportional |
| `SmartStockPolicy` (full agent) | Rules + A* | Genetic Algorithm |

## Directory tree

```
smartstock-ai/
├── app.py                  # Streamlit dashboard (live sandbox + benchmark viewer)
├── main.py                 # CLI: data / demo / quick / full
├── config.py               # every tunable constant (costs, GA params, scenarios, ...)
├── requirements.txt
├── README.md
├── src/
│   ├── __init__.py
│   ├── models.py           # Product, PlanState, PlanProblem, AllocationProblem
│   ├── demand.py           # 30 reproducible scenarios, cached as CSV
│   ├── env.py              # InventoryEnv simulator + cost accounting
│   ├── rules.py            # RuleEngine: when to re-plan
│   ├── planners.py         # AStarPlanner, UniformCostPlanner
│   ├── allocator.py        # Equal / Proportional / Genetic allocators
│   ├── policies.py         # the four policies
│   └── evaluator.py        # experiments, CSV tables, 5 charts
├── tests/
│   ├── test_env.py
│   ├── test_planners.py
│   └── test_allocator.py
├── data/scenarios/         # scenario_01.csv ... scenario_30.csv   (generated)
└── results/                # summary_metrics.csv, detailed_runs.csv, charts/ (generated)
```

## Quickstart

```bash
pip install -r requirements.txt

pytest                                   # unit tests (env, planners, allocator)

python main.py data                      # generate / verify the 30 demand CSVs
python main.py demo --policy smartstock --scenario 21
python main.py quick                     # smoke test: scenarios 1, 11, 21; one GA seed
python main.py full                      # everything: tables + 5 charts (30 scenarios x 5 GA seeds)

streamlit run app.py                     # interactive dashboard
```

> **Note on `--all`:** `main.py` has no `--all` flag. The full benchmark command is **`python main.py full`**
> (use `python main.py full --scenarios 1 11 21 --ga-seeds 0 1` for a subset).

Outputs: `results/summary_metrics.csv`, `results/detailed_runs.csv`, `results/astar_vs_ucs.csv`,
`results/sensitivity_penalty.csv`, and `results/charts/chart1_total_cost.png` ... `chart5_sensitivity_penalty.png`.

## Simulator rules (`src/env.py`)

Daily order: supplier orders due today arrive -> warehouse ships to stores (limited by stock **and** truck capacity)
-> demand is revealed -> stores sell what they have, the rest is a **lost sale** -> costs are booked
(ordering + holding + stock-out). New orders are placed at the start of the day and, since `lead_time >= 1`,
never arrive the same day.

---

# Lab Viva Q&A Cheat Sheet

### Q1. Why combine A\* and a Genetic Algorithm? Why a two-stage architecture?

The problem is really two different problems glued together:

| | Stage 1: *how much to order* | Stage 2: *where to send stock* |
|---|---|---|
| Structure | Sequential, time-dependent: today's order changes tomorrow's stock | One-shot, no time dimension: split what is in the warehouse today |
| Size per product | Small state `(day, stock, pipeline)`, ~11 actions per day | `S x P` integers (15 genes), huge combinatorial space, but any gene vector is a candidate |
| Best tool | **A\*** - exact, optimal, explainable path through states | **GA** - flexible, handles non-linear cost + several coupled constraints with a penalty term |

- **Why not one search for everything?** The joint state (3 stores x 5 products x pipelines) explodes. Decomposing it
  lets A\* plan on *aggregate* stock per product (warehouse + all stores), and the allocator handle the store split.
- **Why A\* for ordering?** Orders are sequential decisions with delays (lead time) and a fixed fee per order; A\* finds
  the *provably cheapest* plan over the horizon and can explain it (a path of states).
- **Why a GA for allocation?** The objective (stock-out + holding cost, truck limit, per-product warehouse limit) is
  piecewise-linear and awkward for search over states; a GA only needs a fitness function, handles both constraints by
  penalty (`CONSTRAINT_PENALTY`), and is seeded with the Equal, Proportional and need-based plans so it starts from
  good solutions and can only improve (elitism).
- **Why a rule engine?** A\* is expensive; cheap IF-THEN rules (low stock, upcoming sale, periodic refresh) decide *when*
  to re-plan - classic rolling-horizon replanning.
- **Safety net:** if A\* hits the node cap (`NODE_CAP = 50,000`) the policy falls back to the reorder-point rule.

### Q2. Why is `h(s) = uncovered_demand x min(unit_cost, stockout_penalty)` admissible?

Definitions: `uncovered_demand = max(0, remaining_forecast_demand - (stock_on_hand + stock_in_transit))`.

Plain-English proof:

1. Uncovered units are demand that **cannot** be served by stock we already hold or have already ordered.
2. From state `s` onward, each such unit has only two possible fates:
   - we **buy** it from the supplier -> costs at least `unit_cost`, or
   - we **lose** the sale -> costs exactly `stockout_penalty`.
3. So each uncovered unit costs **at least** `min(unit_cost, stockout_penalty)`.
4. The true remaining cost `h*(s)` pays all of that **plus** things `h` ignores: the $50 fixed fee of each order, all
   holding costs, and any penalty for bad timing. All ignored terms are `>= 0`.
5. Therefore `0 <= h(s) <= h*(s)`: `h` never overestimates -> **A\* returns an optimal plan**.

It is also **consistent**: ordering `q` units lowers `h` by at most `unit_cost x q`, and serving/losing a day's demand
lowers it by at most `penalty x unmet` - and both amounts are paid in `g`. So `f = g + h` never decreases along a path
and a state is never re-opened.

Tests: `tests/test_planners.py` checks `h >= 0`, `h <= h*` (with `h*` computed by Uniform-Cost Search on the sub-problem
from every state of the optimal path), identical optimal cost for A\* and UCS, and `nodes(A*) <= nodes(UCS)`.

### Q3. What does the 30-scenario benchmark show, and how should I read it?

Setup: scenarios 1-10 **steady**, 11-20 **weekly** pattern (1.4x Fri-Sun, 0.9x Mon-Thu), 21-30 **sale spikes** (2.5x on
3 days); GA policies are averaged over 5 seeds; the std in the tables is across scenarios.

What each experiment is designed to isolate:

| Experiment | Comparison | Question answered |
|---|---|---|
| Chart 1 / `summary_metrics.csv` | all four policies | Does the full agent beat the reorder-point baseline? |
| Ablation: `Rules+A*+Prop` vs `Reorder-Point` | ordering only (both proportional allocation) | What does **A\* ordering** contribute? |
| Ablation: `SmartStock AI` vs `Rules+A*+Prop` | allocation only (same A\* orders) | What does the **GA allocation** contribute? |
| Ablation: `Rules+A*+Equal` vs `Rules+A*+Prop` | allocation baselines | Does demand-aware splitting beat equal splitting? |
| Chart 2 | fill rate vs average inventory | Is a policy better, or just holding more stock? |
| Chart 3 | A\* vs UCS nodes expanded | Does the heuristic reduce search effort at equal (optimal) cost? |
| Chart 4 | GA best fitness per generation | Does the GA converge, and how fast? |
| Chart 5 | stock-out penalty x0.5 ... x10 | How robust is each policy when lost sales get more expensive? |

**Findings to quote - fill these in from your own `results/summary_metrics.csv` after `python main.py full`:**

| Finding | Where to read it | Your numbers |
|---|---|---|
| Total cost of SmartStock AI vs Reorder-Point, per scenario type | `summary_metrics.csv`, column `total_cost` | ____ |
| Fill rate and stock-out days of each policy | `fill_rate_pct`, `stockout_days` | ____ |
| Gain from A\* (Prop vs Reorder-Point) vs gain from GA (SmartStock vs Prop) | difference of the `total_cost` means | ____ |
| Nodes expanded: A\* vs UCS at horizon 14 | `astar_vs_ucs.csv` / Chart 3 | ____ |
| GA generations until early stopping | Chart 4 | ____ |
| Cost slope as penalty goes x0.5 -> x10 | Chart 5 | ____ |

Points that follow from the design (verify against your numbers before claiming them):

- Calendar-aware forecasts let A\* pre-order before sale days, where the reorder-point rule - which only sees *average*
  demand - cannot; expect the gap to be largest in **sale** scenarios and smallest in **steady** ones.
- A\* and UCS must return the **same cost** (both optimal); only `nodes_expanded` differs.
- The GA is seeded with the Proportional and Equal plans and uses elitism, so its best fitness is non-decreasing
  and it should never allocate worse than those baselines **on its own fitness function** (checked in tests);
  the real-cost gain is smaller when the truck is not a binding constraint.
- Higher stock-out penalties push every policy toward holding more stock; policies that plan ahead should degrade
  more gracefully.

### Q4. Other likely viva questions

- **Where does this constant come from?** Everything is in `config.py`; nothing is hard-coded elsewhere.
- **How is the experiment reproducible?** Demand per scenario uses fixed seeds (`5000 + id`, sale days `1000 + id`) and is
  cached as CSV; GA seeds are fixed (`GA_SEEDS`) and the GA re-seeds in `reset()`.
- **What if the planner is too slow?** `NODE_CAP` bounds A\*; results are memoised in a cache; the rule engine avoids
  needless re-plans; on failure the policy falls back to the (s, S) rule.
- **How are lost sales treated?** They are lost (no backorders): they cost `stockout_penalty` per unit and lower
  the fill rate. `sales + unmet == realized demand` and `start + arrivals - sales == end stock` are unit-tested.
- **Limitations?** A\* plans on aggregate stock (ignores the store split); forecasts are noise-free calendar
  expectations while realized demand has 10% noise; the GA uses penalty-only constraints (no repair step), so
  feasibility relies on feasible seeds and the large penalty; the environment clips any infeasible shipment anyway.
