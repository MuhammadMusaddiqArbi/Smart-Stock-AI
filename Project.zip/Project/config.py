"""Central configuration for SmartStock AI.

Every tunable number lives here so that experiments are reproducible and the
viva answer to "where does this constant come from?" is always "config.py".
"""
from pathlib import Path

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data" / "scenarios"
RESULTS_DIR = ROOT / "results"
CHARTS_DIR = RESULTS_DIR / "charts"

# --------------------------------------------------------------------------
# Supply-chain topology
# --------------------------------------------------------------------------
NUM_PRODUCTS = 5                      # configurable (templates repeat if > 5)
NUM_STORES = 3
STORE_SHARES = (0.5, 0.3, 0.2)        # share of total system demand per store
SIM_DAYS = 90                         # simulation horizon

# --------------------------------------------------------------------------
# Costs & logistics
# --------------------------------------------------------------------------
FIXED_ORDER_FEE = 50.0                # $ per non-zero supplier order
TRUCK_CAPACITY = 250                  # units/day, warehouse -> stores, all products
INITIAL_WAREHOUSE_DAYS = 3            # warehouse starts with 3 days of system demand
INITIAL_STORE_DAYS = 2                # each store starts with 2 days of its own demand

# --------------------------------------------------------------------------
# Demand scenarios
# --------------------------------------------------------------------------
NUM_SCENARIOS = 30                    # 1-10 steady, 11-20 weekly, 21-30 sale spikes
DEMAND_NOISE_SD = 0.10                # "light" multiplicative Gaussian noise
WEEKEND_MULT = 1.4                    # Fri, Sat, Sun
WEEKDAY_MULT = 0.9                    # Mon - Thu
SALE_MULT = 2.5
NUM_SALE_DAYS = 3
SCENARIO_KINDS = ("steady", "weekly", "sale")

# --------------------------------------------------------------------------
# Planning (rules + A*)
# --------------------------------------------------------------------------
PLANNING_HORIZON = 14                 # rolling-horizon length in days
ORDER_QUANTITIES = tuple(range(0, 101, 10))   # 0, 10, ..., 100 units per order
ORDER_STEP = 10                       # lot size (also used by the baseline)
NODE_CAP = 50_000                     # max A* node expansions before fallback
RULE_REFRESH_DAYS = 3                 # periodic re-plan even with no alert
SAFETY_DAYS = 1                       # safety buffer (days of demand)

# --------------------------------------------------------------------------
# Warehouse -> store allocation
# --------------------------------------------------------------------------
ALLOC_LOOKAHEAD_DAYS = 2              # stores are topped up to cover this many days
CONSTRAINT_PENALTY = 10_000.0         # GA penalty per unit of constraint violation

GA_PARAMS = dict(
    population_size=60,
    tournament_size=3,
    mutation_rate=0.1,
    mutation_step=5,                  # mutation = integer step in [-5, +5]
    crossover_rate=0.9,
    elitism=2,
    max_generations=150,
    early_stopping=20,
)
GA_SEEDS = (0, 1, 2, 3, 4)            # 5 fixed seeds for SmartStockPolicy

# --------------------------------------------------------------------------
# Experiments
# --------------------------------------------------------------------------
PENALTY_MULTIPLIERS = (0.5, 1.0, 2.0, 5.0, 10.0)
SENSITIVITY_SCENARIOS = (1, 2, 11, 12, 21, 22)   # 2 per scenario type
ASTAR_UCS_HORIZONS = (3, 5, 7, 10, 14)
ASTAR_UCS_SCENARIOS = tuple(range(1, 31, 3))     # 10 scenarios spanning all types

# --------------------------------------------------------------------------
# Product templates: (name, lead_time, unit_cost, holding_cost, stockout_penalty,
#                     base_demand per day for the WHOLE system)
# --------------------------------------------------------------------------
PRODUCT_TEMPLATES = [
    ("Rice 5kg",        2,  8.0, 0.20, 12.0, 40),
    ("Cooking Oil 1L",  3,  6.0, 0.15, 10.0, 30),
    ("Detergent",       1, 12.0, 0.30, 20.0, 25),
    ("Tea Box",         2, 10.0, 0.25, 15.0, 20),
    ("Snack Pack",      1,  4.0, 0.10,  6.0, 15),
]