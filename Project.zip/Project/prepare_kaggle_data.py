import pandas as pd
from pathlib import Path

# 1. Load Kaggle dataset
df = pd.read_csv("train.csv")
df["date"] = pd.to_datetime(df["date"])

# 2. Filter to 3 stores (1, 2, 3), 5 items (1..5), and a 90-day window
start_date = pd.Timestamp("2017-01-01")
end_date = start_date + pd.Timedelta(days=89)

sub = df[
    (df["store"].isin([1, 2, 3])) &
    (df["item"].isin([1, 2, 3, 4, 5])) &
    (df["date"] >= start_date) &
    (df["date"] <= end_date)
].copy()

# 3. Map columns to SmartStock AI's schema
sub["day"] = (sub["date"] - start_date).dt.days
sub["store_id"] = sub["store"] - 1
product_map = {1: "P1", 2: "P2", 3: "P3", 4: "P4", 5: "P5"}
sub["product_id"] = sub["item"].map(product_map)
sub["seed"] = 31
sub["regime"] = "real_world"

out_df = sub[["seed", "regime", "day", "store_id", "product_id", "sales"]].rename(
    columns={"sales": "demand"}
).sort_values(["day", "product_id", "store_id"])

# 4. Save to data/scenarios/scenario_31.csv
out_path = Path("data/scenarios/scenario_31.csv")
out_path.parent.mkdir(parents=True, exist_ok=True)
out_df.to_csv(out_path, index=False)
print(f"Created {out_path} with {len(out_df)} rows!")