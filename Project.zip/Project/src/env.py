"""InventoryEnv: the simulator and the single source of truth for cost accounting.

Daily step order (matches the project spec):
  1. supplier orders due today arrive at the warehouse
  2. warehouse stock is shipped to the stores (limited by stock AND truck capacity)
  3. today's realized demand is revealed
  4. stores sell what they have; the rest is a LOST SALE (penalty, lowers fill rate)
  5. costs are booked: ordering + holding (warehouse + stores) + stock-out penalty

New supplier orders are placed at the start of the day; because lead_time >= 1
they can never arrive on the day they were placed.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple, Union

import numpy as np

import config as cfg
from .demand import DemandGenerator
from .models import Product, default_products


class InventoryEnv:
    def __init__(self, products: Optional[Sequence[Product]] = None,
                 truck_capacity: int = cfg.TRUCK_CAPACITY,
                 penalty_multiplier: float = 1.0,
                 horizon: int = cfg.SIM_DAYS,
                 store_shares: Sequence[float] = cfg.STORE_SHARES,
                 fixed_order_fee: float = cfg.FIXED_ORDER_FEE,
                 data_dir: Path = cfg.DATA_DIR):
        base = list(products) if products is not None else default_products()
        # The multiplier is applied to the products themselves, so planners and
        # allocators automatically "know" the (scaled) penalty they are facing.
        self.products: List[Product] = [p.with_penalty_multiplier(penalty_multiplier) for p in base]
        self.penalty_multiplier = penalty_multiplier
        self.truck_capacity = int(truck_capacity)
        self.horizon = horizon
        self.store_shares = np.asarray(store_shares, dtype=float)
        self.fixed_order_fee = fixed_order_fee
        self.data_dir = Path(data_dir)

        self.num_products = len(self.products)
        self.num_stores = len(self.store_shares)
        self.lead = np.array([p.lead_time for p in self.products])
        self.unit_cost = np.array([p.unit_cost for p in self.products])
        self.holding = np.array([p.holding_cost for p in self.products])
        self.penalty = np.array([p.stockout_penalty for p in self.products])
        self.gen: Optional[DemandGenerator] = None

    # ------------------------------------------------------------------
    # Episode control
    # ------------------------------------------------------------------
    def reset(self, seed: int = 1) -> "InventoryEnv":
        """Start a new episode on scenario `seed` (1-30 are cached as CSV files)."""
        self.scenario_id = seed
        self.gen = DemandGenerator.load_or_create(
            seed, self.data_dir, self.products, self.horizon, self.store_shares)
        self._demand = self.gen.realized()
        self.day = 0

        total_base = np.array([p.base_demand for p in self.products])
        self.wh_stock = np.rint(cfg.INITIAL_WAREHOUSE_DAYS * total_base).astype(int)
        self.store_stock = np.rint(cfg.INITIAL_STORE_DAYS * self.gen.base).astype(int)
        self.pipeline: List[Tuple[int, int, int]] = []   # (arrival_day, product, qty)

        self.history: List[Dict] = []
        self.totals = dict(ordering=0.0, holding=0.0, stockout=0.0,
                           demand_units=0, sold_units=0, lost_units=0,
                           stockout_days=0, num_orders=0)
        return self

    @property
    def done(self) -> bool:
        return self.day >= self.horizon

    # ------------------------------------------------------------------
    # State queries (used by rules, planners and policies)
    # ------------------------------------------------------------------
    def total_stock(self, p: int) -> int:
        """Units of product `p` on hand: warehouse + all stores."""
        return int(self.wh_stock[p] + self.store_stock[:, p].sum())

    def pipeline_qty(self, p: int) -> int:
        """Units of product `p` ordered but not yet arrived."""
        return int(sum(q for (_, pp, q) in self.pipeline if pp == p))

    def pipeline_for(self, p: int) -> Tuple[Tuple[int, int], ...]:
        """Sorted ((arrival_day, qty), ...) for product `p`, merged per arrival day."""
        merged: Dict[int, int] = {}
        for arrival, pp, q in self.pipeline:
            if pp == p:
                merged[arrival] = merged.get(arrival, 0) + q
        return tuple(sorted(merged.items()))

    def inventory_position(self, p: int) -> int:
        """On-hand (warehouse + stores) plus on-order stock for product `p`."""
        return self.total_stock(p) + self.pipeline_qty(p)

    # ------------------------------------------------------------------
    # One simulated day
    # ------------------------------------------------------------------
    def _orders_vector(self, orders: Union[None, Dict[int, int], Sequence[int], np.ndarray]) -> np.ndarray:
        vec = np.zeros(self.num_products, dtype=int)
        if orders is None:
            return vec
        if isinstance(orders, dict):
            for p, q in orders.items():
                vec[int(p)] = int(q)
        else:
            vec = np.asarray(orders, dtype=int).copy()
        return np.maximum(vec, 0)

    def _feasible_shipment(self, allocation: Optional[np.ndarray]) -> np.ndarray:
        """Clip a requested (S, P) shipment to warehouse stock and truck capacity."""
        if allocation is None:
            return np.zeros((self.num_stores, self.num_products), dtype=int)
        ship = np.maximum(np.asarray(allocation, dtype=float), 0.0)
        # per product: cannot ship more than the warehouse holds
        for p in range(self.num_products):
            total = ship[:, p].sum()
            if total > self.wh_stock[p]:
                ship[:, p] = ship[:, p] * (self.wh_stock[p] / total)
        ship = np.floor(ship + 1e-9)
        # one truck for everything
        total = ship.sum()
        if total > self.truck_capacity:
            ship = np.floor(ship * (self.truck_capacity / total) + 1e-9)
        ship = ship.astype(int)
        # integer safety net (floor can never exceed, but guard against rounding)
        for p in range(self.num_products):
            while ship[:, p].sum() > self.wh_stock[p]:
                ship[int(np.argmax(ship[:, p])), p] -= 1
        return ship

    def step(self, orders: Union[None, Dict[int, int], Sequence[int], np.ndarray] = None,
             allocation: Optional[np.ndarray] = None) -> Dict:
        """Play one day.

        orders     : supplier orders placed today, a dict {product: qty} or a (P,) array
        allocation : requested warehouse -> store shipment, (S, P); it is clipped to the
                     warehouse stock and the truck capacity (see `_feasible_shipment`)
        Returns a dict describing the day (costs, shipped, demand, unmet, ...).
        """
        if self.done:
            raise RuntimeError("Episode finished: call reset() first.")
        day = self.day
        order_vec = self._orders_vector(orders)

        # --- new supplier orders (placed at the start of the day) ---------
        ordering_cost = 0.0
        for p in range(self.num_products):
            q = int(order_vec[p])
            if q > 0:
                self.pipeline.append((day + int(self.lead[p]), p, q))
                ordering_cost += self.fixed_order_fee + self.unit_cost[p] * q
                self.totals["num_orders"] += 1

        # --- 1. arrivals ---------------------------------------------------
        still_moving = []
        for arrival, p, q in self.pipeline:
            if arrival <= day:
                self.wh_stock[p] += q
            else:
                still_moving.append((arrival, p, q))
        self.pipeline = still_moving

        # --- 2. warehouse -> stores ---------------------------------------
        ship = self._feasible_shipment(allocation)
        self.wh_stock = self.wh_stock - ship.sum(axis=0)
        self.store_stock = self.store_stock + ship

        # --- 3. demand revealed -------------------------------------------
        demand = self._demand[day]                       # (S, P)

        # --- 4. sales and lost sales --------------------------------------
        sold = np.minimum(self.store_stock, demand)
        unmet = demand - sold
        self.store_stock = self.store_stock - sold

        # --- 5. cost booking ----------------------------------------------
        holding_cost = float(np.sum(self.holding * (self.wh_stock + self.store_stock.sum(axis=0))))
        stockout_cost = float(np.sum(self.penalty * unmet.sum(axis=0)))
        day_cost = ordering_cost + holding_cost + stockout_cost

        self.totals["ordering"] += ordering_cost
        self.totals["holding"] += holding_cost
        self.totals["stockout"] += stockout_cost
        self.totals["demand_units"] += int(demand.sum())
        self.totals["sold_units"] += int(sold.sum())
        self.totals["lost_units"] += int(unmet.sum())
        if unmet.sum() > 0:
            self.totals["stockout_days"] += 1

        info = dict(day=day, ordering=ordering_cost, holding=holding_cost,
                    stockout=stockout_cost, cost=day_cost,
                    demand=int(demand.sum()), unmet=int(unmet.sum()),
                    shipped=int(ship.sum()),
                    inventory=int(self.wh_stock.sum() + self.store_stock.sum()),
                    orders={int(p): int(order_vec[p]) for p in range(self.num_products) if order_vec[p] > 0})
        self.history.append(info)
        self.day += 1
        info["done"] = self.done
        return info

    # ------------------------------------------------------------------
    # Results
    # ------------------------------------------------------------------
    def summary(self) -> Dict:
        """Episode KPIs: costs, fill rate, average inventory and stock-out days."""
        t = self.totals
        demand_units = t["demand_units"]
        fill_rate = t["sold_units"] / demand_units if demand_units > 0 else 1.0
        avg_inventory = float(np.mean([h["inventory"] for h in self.history])) if self.history else 0.0
        return dict(
            total_cost=t["ordering"] + t["holding"] + t["stockout"],
            ordering_cost=t["ordering"],
            holding_cost=t["holding"],
            stockout_cost=t["stockout"],
            fill_rate=fill_rate,
            avg_inventory=avg_inventory,
            stockout_days=t["stockout_days"],
            num_orders=t["num_orders"],
            lost_units=t["lost_units"],
        )
