"""Demand generation: 30 reproducible scenarios cached as CSV files.

Scenario ids 1-10 are *steady*, 11-20 have a *weekly* pattern and 21-30 contain
*sale-day* spikes.  The deterministic part of demand (`forecast`) is separated
from the random part (`realized`), so planners can use the forecast while the
simulator plays the noisy realization.
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import config as cfg
from .models import Product, default_products


def scenario_kind(scenario_id: int) -> str:
    """1-10 steady, 11-20 weekly, 21-30 sale (other ids cycle through the kinds)."""
    return cfg.SCENARIO_KINDS[((scenario_id - 1) // 10) % 3]


class DemandGenerator:
    """Demand model for ONE scenario."""

    def __init__(self, scenario_id: int, products: Optional[Sequence[Product]] = None,
                 horizon: int = cfg.SIM_DAYS, store_shares: Sequence[float] = cfg.STORE_SHARES,
                 noise_sd: float = cfg.DEMAND_NOISE_SD):
        self.scenario_id = scenario_id
        self.kind = scenario_kind(scenario_id)
        self.products = list(products) if products is not None else default_products()
        self.horizon = horizon
        self.shares = np.asarray(store_shares, dtype=float)
        self.noise_sd = noise_sd
        self.num_stores = len(self.shares)
        self.num_products = len(self.products)

        # (S, P) expected demand per day before weekly / event effects
        self.base = np.outer(self.shares, [p.base_demand for p in self.products])

        # Sale days are a deterministic function of the scenario id (so the
        # calendar can be re-derived when a CSV is loaded).
        self.sale_days: Tuple[int, ...] = ()
        if self.kind == "sale":
            rng = np.random.default_rng(1000 + scenario_id)
            days = rng.choice(np.arange(7, horizon - 5), size=cfg.NUM_SALE_DAYS, replace=False)
            self.sale_days = tuple(sorted(int(d) for d in days))

        self._realized: Optional[np.ndarray] = None

    # ------------------------------------------------------------------
    # Deterministic part
    # ------------------------------------------------------------------
    def weekly_pattern(self, day: int) -> float:
        """Day 0 is a Monday.  Fri-Sun = 1.4x, Mon-Thu = 0.9x (weekly scenarios only)."""
        if self.kind != "weekly":
            return 1.0
        return cfg.WEEKEND_MULT if day % 7 >= 4 else cfg.WEEKDAY_MULT

    def event_uplift(self, day: int) -> float:
        """Calendar knowledge: 2.5x on scheduled sale days, else 1.0."""
        return cfg.SALE_MULT if day in self.sale_days else 1.0

    def forecast(self, day: int) -> np.ndarray:
        """Expected demand (S, P) = base_level * weekly_pattern * event_uplift (no noise)."""
        return self.base * self.weekly_pattern(day) * self.event_uplift(day)

    def total_forecast(self, day: int) -> np.ndarray:
        """Expected system-wide demand per product, shape (P,)."""
        return self.forecast(day).sum(axis=0)

    # ------------------------------------------------------------------
    # Random part
    # ------------------------------------------------------------------
    def _generate(self) -> np.ndarray:
        """Draw one noisy realization, shape (horizon, S, P), non-negative integers."""
        rng = np.random.default_rng(5000 + self.scenario_id)
        out = np.zeros((self.horizon, self.num_stores, self.num_products), dtype=int)
        for day in range(self.horizon):
            noise = rng.normal(1.0, self.noise_sd, size=(self.num_stores, self.num_products))
            out[day] = np.maximum(0, np.rint(self.forecast(day) * noise)).astype(int)
        return out

    def realized(self) -> np.ndarray:
        """Realized demand, shape (horizon, S, P); generated once and then cached."""
        if self._realized is None:
            self._realized = self._generate()
        return self._realized

    # ------------------------------------------------------------------
    # CSV caching
    # ------------------------------------------------------------------
    @staticmethod
    def csv_path(scenario_id: int, data_dir: Path = cfg.DATA_DIR) -> Path:
        return Path(data_dir) / f"scenario_{scenario_id:02d}.csv"

    def to_dataframe(self) -> pd.DataFrame:
        """Long format: one row per (day, store, product)."""
        d = self.realized()
        days, stores, prods = np.indices(d.shape)
        return pd.DataFrame({"day": days.ravel(), "store": stores.ravel(),
                             "product": prods.ravel(), "demand": d.ravel()})

    def save_csv(self, data_dir: Path = cfg.DATA_DIR) -> Path:
        path = self.csv_path(self.scenario_id, data_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.to_dataframe().to_csv(path, index=False)
        return path

    def _load_csv(self, path: Path) -> bool:
        """Fill `_realized` from `path`; return False if the file does not match this setup."""
        try:
            df = pd.read_csv(path)
            shape = (self.horizon, self.num_stores, self.num_products)
            if len(df) != int(np.prod(shape)):
                return False
            arr = np.zeros(shape, dtype=int)
            arr[df["day"].to_numpy(), df["store"].to_numpy(),
                df["product"].to_numpy()] = df["demand"].to_numpy()
        except (OSError, KeyError, ValueError, IndexError, pd.errors.ParserError):
            return False
        self._realized = arr
        return True

    @classmethod
    def load_or_create(cls, scenario_id: int, data_dir: Path = cfg.DATA_DIR,
                       products: Optional[Sequence[Product]] = None,
                       horizon: int = cfg.SIM_DAYS,
                       store_shares: Sequence[float] = cfg.STORE_SHARES,
                       noise_sd: float = cfg.DEMAND_NOISE_SD) -> "DemandGenerator":
        """Return the generator for a scenario, using the CSV cache in `data_dir`.

        If the CSV is missing it is created.  If it exists but its shape does
        not match the requested topology, the demand is regenerated in memory
        and the file is left untouched.
        """
        gen = cls(scenario_id, products, horizon, store_shares, noise_sd)
        path = cls.csv_path(scenario_id, data_dir)
        if path.exists():
            if gen._load_csv(path):
                return gen
            gen._realized = gen._generate()
            return gen
        gen.realized()
        gen.save_csv(data_dir)
        return gen


def ensure_all_scenarios(data_dir: Path = cfg.DATA_DIR, n: int = cfg.NUM_SCENARIOS,
                         products: Optional[Sequence[Product]] = None,
                         horizon: int = cfg.SIM_DAYS,
                         store_shares: Sequence[float] = cfg.STORE_SHARES) -> List[Path]:
    """Make sure CSV files for scenarios 1..n exist; return their paths."""
    paths = []
    for sid in range(1, n + 1):
        DemandGenerator.load_or_create(sid, data_dir, products, horizon, store_shares)
        paths.append(DemandGenerator.csv_path(sid, data_dir))
    return paths
