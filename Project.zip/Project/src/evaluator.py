"""Evaluator: runs every policy on every scenario, writes CSV tables and 5 charts."""
from __future__ import annotations

import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import config as cfg
from .demand import scenario_kind
from .env import InventoryEnv
from .models import PlanProblem
from .planners import AStarPlanner, UniformCostPlanner
from .policies import (Policy, ReorderPointPolicy, RulesAStarEqualPolicy,
                       RulesAStarPropPolicy, SmartStockPolicy)

METRICS = ["total_cost", "ordering_cost", "holding_cost", "stockout_cost",
           "fill_rate_pct", "avg_inventory", "stockout_days"]
KINDS = list(cfg.SCENARIO_KINDS)
DPI = 200


def run_episode(policy: Policy, seed: int, truck_capacity: int = cfg.TRUCK_CAPACITY,
                penalty_multiplier: float = 1.0) -> Tuple[Dict, InventoryEnv]:
    """Play one full episode of `policy` on scenario `seed`; return (summary, env)."""
    env = InventoryEnv(truck_capacity=truck_capacity, penalty_multiplier=penalty_multiplier)
    env.reset(seed)
    policy.reset()
    while not env.done:
        orders, allocation = policy.decide(env)
        env.step(orders, allocation)
    return env.summary(), env


class Evaluator:
    def __init__(self, scenarios: Optional[Sequence[int]] = None,
                 ga_seeds: Optional[Sequence[int]] = None,
                 results_dir: Path = cfg.RESULTS_DIR, charts_dir: Path = cfg.CHARTS_DIR,
                 verbose: bool = True):
        self.scenarios = list(scenarios) if scenarios is not None else list(range(1, cfg.NUM_SCENARIOS + 1))
        self.ga_seeds = list(ga_seeds) if ga_seeds is not None else list(cfg.GA_SEEDS)
        self.results_dir, self.charts_dir = Path(results_dir), Path(charts_dir)
        self.results_dir.mkdir(parents=True, exist_ok=True)
        self.charts_dir.mkdir(parents=True, exist_ok=True)
        self.verbose = verbose

        # one instance per policy (the A* cache stays valid across scenarios)
        self.baselines: List[Policy] = [ReorderPointPolicy(), RulesAStarEqualPolicy(),
                                        RulesAStarPropPolicy()]
        self.smart: Dict[int, SmartStockPolicy] = {s: SmartStockPolicy(ga_seed=s) for s in self.ga_seeds}
        self.policy_order = [p.name for p in self.baselines] + [SmartStockPolicy.name]

        self.detailed: Optional[pd.DataFrame] = None
        self.per_scenario: Optional[pd.DataFrame] = None
        self.summary: Optional[pd.DataFrame] = None
        self.ga_histories: Dict[str, List[List[float]]] = {k: [] for k in KINDS}
        self.astar_ucs: Optional[pd.DataFrame] = None
        self.sensitivity: Optional[pd.DataFrame] = None

    def _log(self, msg: str) -> None:
        if self.verbose:
            print(msg, flush=True)

    @staticmethod
    def _row(policy: str, scenario: int, ga_seed, s: Dict) -> Dict:
        return dict(policy=policy, scenario=scenario, kind=scenario_kind(scenario), ga_seed=ga_seed,
                    total_cost=s["total_cost"], ordering_cost=s["ordering_cost"],
                    holding_cost=s["holding_cost"], stockout_cost=s["stockout_cost"],
                    fill_rate_pct=100.0 * s["fill_rate"], avg_inventory=s["avg_inventory"],
                    stockout_days=s["stockout_days"])

    # ------------------------------------------------------------------
    # Main experiment
    # ------------------------------------------------------------------
    def run_main(self) -> pd.DataFrame:
        rows, t0 = [], time.time()
        for i, scen in enumerate(self.scenarios, 1):
            for pol in self.baselines:
                s, _ = run_episode(pol, scen)
                rows.append(self._row(pol.name, scen, "", s))
            for gs, pol in self.smart.items():
                s, _ = run_episode(pol, scen)
                rows.append(self._row(pol.name, scen, gs, s))
                if gs == self.ga_seeds[0]:
                    self.ga_histories[scenario_kind(scen)].extend(pol.ga_histories)
            self._log(f"[main] scenario {scen} done ({i}/{len(self.scenarios)}, {time.time() - t0:.0f}s)")
        self.detailed = pd.DataFrame(rows)
        # average GA seeds first, so std reflects variation ACROSS SCENARIOS only
        self.per_scenario = (self.detailed.groupby(["policy", "scenario", "kind"], as_index=False)[METRICS].mean())
        self.summary = self._summarise(self.per_scenario)
        return self.detailed

    def _summarise(self, per_scen: pd.DataFrame) -> pd.DataFrame:
        recs = []
        groups = [(k, per_scen[per_scen["kind"] == k]) for k in KINDS] + [("all", per_scen)]
        for kind, g in groups:
            for pol in self.policy_order:
                sub = g[g["policy"] == pol]
                if sub.empty:
                    continue
                rec = dict(policy=pol, scenario_type=kind, n_scenarios=len(sub))
                for m in METRICS:
                    mean, std = sub[m].mean(), sub[m].std(ddof=1)
                    std = 0.0 if np.isnan(std) else std
                    rec[f"{m}_mean"], rec[f"{m}_std"] = mean, std
                    rec[m] = f"{mean:.2f} ± {std:.2f}"
                recs.append(rec)
        return pd.DataFrame(recs)

    def save_tables(self) -> Tuple[Path, Path]:
        if self.detailed is None:
            self.run_main()
        p1, p2 = self.results_dir / "summary_metrics.csv", self.results_dir / "detailed_runs.csv"
        self.summary.to_csv(p1, index=False)
        self.detailed.to_csv(p2, index=False)
        return p1, p2

    # ------------------------------------------------------------------
    # Chart helpers
    # ------------------------------------------------------------------
    def _colors(self) -> Dict[str, tuple]:
        cmap = plt.get_cmap("tab10")
        return {name: cmap(i) for i, name in enumerate(self.policy_order)}

    def _save(self, fig, name: str) -> Path:
        path = self.charts_dir / name
        fig.tight_layout()
        fig.savefig(path, dpi=DPI, bbox_inches="tight")
        plt.close(fig)
        self._log(f"saved {path}")
        return path

    # Chart 1 ----------------------------------------------------------
    def chart1_total_cost(self) -> Path:
        colors, n = self._colors(), len(self.policy_order)
        width = 0.8 / n
        fig, ax = plt.subplots(figsize=(9, 5.5))
        for i, pol in enumerate(self.policy_order):
            means, stds = [], []
            for k in KINDS:
                r = self.summary[(self.summary.policy == pol) & (self.summary.scenario_type == k)]
                means.append(float(r.total_cost_mean.iloc[0]) if len(r) else np.nan)
                stds.append(float(r.total_cost_std.iloc[0]) if len(r) else 0.0)
            ax.bar(np.arange(len(KINDS)) + (i - (n - 1) / 2) * width, means, width, yerr=stds,
                   capsize=3, label=pol, color=colors[pol])
        ax.set_xticks(range(len(KINDS)))
        ax.set_xticklabels([k.capitalize() for k in KINDS])
        ax.set_xlabel("Scenario type")
        ax.set_ylabel("Total cost over 90 days ($)")
        ax.set_title("Total cost per policy (mean ± std across scenarios)")
        ax.legend()
        ax.grid(axis="y", alpha=0.3)
        return self._save(fig, "chart1_total_cost.png")

    # Chart 2 ----------------------------------------------------------
    def chart2_fill_rate_vs_inventory(self) -> Path:
        colors = self._colors()
        markers = dict(zip(KINDS, ["o", "s", "^"]))
        fig, ax = plt.subplots(figsize=(8.5, 6))
        for pol in self.policy_order:
            for k in KINDS:
                r = self.summary[(self.summary.policy == pol) & (self.summary.scenario_type == k)]
                if r.empty:
                    continue
                ax.errorbar(r.avg_inventory_mean.iloc[0], r.fill_rate_pct_mean.iloc[0],
                            xerr=r.avg_inventory_std.iloc[0], yerr=r.fill_rate_pct_std.iloc[0],
                            fmt=markers[k], color=colors[pol], markersize=9, alpha=0.85,
                            elinewidth=1, capsize=2)
        handles = [plt.Line2D([], [], marker="o", ls="", color=colors[p], label=p) for p in self.policy_order]
        handles += [plt.Line2D([], [], marker=markers[k], ls="", color="gray", label=f"{k} scenarios") for k in KINDS]
        ax.legend(handles=handles, loc="best")
        ax.set_xlabel("Average inventory (units on hand)")
        ax.set_ylabel("Fill rate (%)")
        ax.set_title("Service level vs. inventory trade-off (top-left is better)")
        ax.grid(alpha=0.3)
        return self._save(fig, "chart2_fill_rate_vs_inventory.png")

    # Chart 3 ----------------------------------------------------------
    def run_astar_vs_ucs(self) -> pd.DataFrame:
        """Solve day-0 planning problems with A* and UCS (h = 0) for several horizons."""
        rows = []
        scen_list = [s for s in cfg.ASTAR_UCS_SCENARIOS]
        for H in cfg.ASTAR_UCS_HORIZONS:
            for scen in scen_list:
                env = InventoryEnv().reset(scen)
                for p in range(env.num_products):
                    demand = tuple(int(round(env.gen.total_forecast(d)[p])) for d in range(H))
                    problem = PlanProblem(env.products[p], 0, env.total_stock(p), (), demand)
                    for planner in (AStarPlanner(), UniformCostPlanner()):
                        res = planner.solve(problem)
                        rows.append(dict(planner=planner.name, horizon=H, scenario=scen, product=p,
                                         nodes=res.nodes_expanded, cost=res.cost, success=res.success))
            self._log(f"[A*/UCS] horizon {H} done")
        self.astar_ucs = pd.DataFrame(rows)
        self.astar_ucs.to_csv(self.results_dir / "astar_vs_ucs.csv", index=False)
        return self.astar_ucs

    def chart3_astar_vs_ucs(self) -> Path:
        if self.astar_ucs is None:
            self.run_astar_vs_ucs()
        fig, ax = plt.subplots(figsize=(8, 5.5))
        for name, style in (("A*", "o-"), ("UCS", "s--")):
            g = self.astar_ucs[self.astar_ucs.planner == name].groupby("horizon")["nodes"]
            mean, std = g.mean(), g.std().fillna(0)
            ax.errorbar(mean.index, mean.values, yerr=std.values, fmt=style, capsize=3,
                        label="A* (admissible h)" if name == "A*" else "Uniform-Cost (h = 0)")
        ax.set_yscale("log")
        ax.set_xticks(list(cfg.ASTAR_UCS_HORIZONS))
        ax.set_xlabel("Planning horizon (days)")
        ax.set_ylabel("Nodes expanded (log scale)")
        ax.set_title(f"Search effort: A* vs UCS (node cap = {cfg.NODE_CAP:,})")
        ax.legend()
        ax.grid(alpha=0.3, which="both")
        return self._save(fig, "chart3_astar_vs_ucs.png")

    # Chart 4 ----------------------------------------------------------
    def chart4_ga_convergence(self) -> Path:
        if not any(self.ga_histories.values()):
            for scen in (1, 11, 21):
                pol = SmartStockPolicy(ga_seed=self.ga_seeds[0])
                run_episode(pol, scen)
                self.ga_histories[scenario_kind(scen)].extend(pol.ga_histories)
        fig, ax = plt.subplots(figsize=(8, 5.5))
        for k in KINDS:
            curves = [c for c in self.ga_histories[k] if len(c) > 1]   # skip trivial (empty-warehouse) calls
            if not curves:
                continue
            L = max(len(c) for c in curves)
            arr = np.array([c + [c[-1]] * (L - len(c)) for c in curves])   # pad early-stopped runs
            mean, sd = arr.mean(axis=0), arr.std(axis=0)
            x = np.arange(L)
            ax.plot(x, mean, label=f"{k} scenarios")
            ax.fill_between(x, mean - sd, mean + sd, alpha=0.15)
        ax.set_xlabel("Generation")
        ax.set_ylabel("Best fitness  (-(stock-out + holding cost))")
        ax.set_title("GA convergence (mean ± std over daily allocation calls)")
        ax.legend()
        ax.grid(alpha=0.3)
        return self._save(fig, "chart4_ga_convergence.png")

    # Chart 5 ----------------------------------------------------------
    def run_sensitivity(self) -> pd.DataFrame:
        policies: List[Policy] = self.baselines + [self.smart.get(self.ga_seeds[0]) or SmartStockPolicy(self.ga_seeds[0])]
        rows = []
        for m in cfg.PENALTY_MULTIPLIERS:
            for scen in cfg.SENSITIVITY_SCENARIOS:
                for pol in policies:
                    s, _ = run_episode(pol, scen, penalty_multiplier=m)
                    rows.append(dict(policy=pol.name, multiplier=m, scenario=scen,
                                     total_cost=s["total_cost"], fill_rate_pct=100 * s["fill_rate"]))
            self._log(f"[sensitivity] penalty x{m} done")
        self.sensitivity = pd.DataFrame(rows)
        self.sensitivity.to_csv(self.results_dir / "sensitivity_penalty.csv", index=False)
        return self.sensitivity

    def chart5_sensitivity_penalty(self) -> Path:
        if self.sensitivity is None:
            self.run_sensitivity()
        colors = self._colors()
        fig, ax = plt.subplots(figsize=(8.5, 5.5))
        for pol in self.policy_order:
            g = self.sensitivity[self.sensitivity.policy == pol].groupby("multiplier")["total_cost"]
            mean, sd = g.mean(), g.std().fillna(0)
            ax.errorbar(mean.index, mean.values, yerr=sd.values, fmt="o-", capsize=3,
                        color=colors[pol], label=pol)
        ax.set_xscale("log")
        ax.set_xticks(list(cfg.PENALTY_MULTIPLIERS))
        ax.set_xticklabels([f"{m:g}x" for m in cfg.PENALTY_MULTIPLIERS])
        ax.set_xlabel("Stock-out penalty multiplier")
        ax.set_ylabel("Total cost ($)")
        ax.set_title("Sensitivity of total cost to the stock-out penalty")
        ax.legend()
        ax.grid(alpha=0.3)
        return self._save(fig, "chart5_sensitivity_penalty.png")

    # ------------------------------------------------------------------
    def run(self) -> None:
        """Full pipeline: experiments, CSV tables and all five charts."""
        self.run_main()
        self.save_tables()
        self.chart1_total_cost()
        self.chart2_fill_rate_vs_inventory()
        self.chart3_astar_vs_ucs()
        self.chart4_ga_convergence()
        self.chart5_sensitivity_penalty()
