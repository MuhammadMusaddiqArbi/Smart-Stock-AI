"""Plain data containers shared by every module (no logic beyond tiny helpers)."""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Dict, List, NamedTuple, Tuple

import numpy as np

import config as cfg


@dataclass(frozen=True)
class Product:
    """One stock-keeping unit. `base_demand` is units/day for the whole system."""
    name: str
    lead_time: int          # days between ordering and arrival at the warehouse
    unit_cost: float        # $ per unit bought from the supplier
    holding_cost: float     # $ per unit per day (warehouse or store)
    stockout_penalty: float  # $ per unit of unmet (lost) demand
    base_demand: float

    def with_penalty_multiplier(self, m: float) -> "Product":
        return replace(self, stockout_penalty=self.stockout_penalty * m)

    def key(self) -> Tuple:
        """Hashable fingerprint of the cost parameters (used as a cache key)."""
        return (self.lead_time, self.unit_cost, self.holding_cost, self.stockout_penalty)


def default_products(n: int = cfg.NUM_PRODUCTS) -> List[Product]:
    """First `n` product templates; templates repeat (with a suffix) if n > 5."""
    out = []
    for i in range(n):
        name, lead, cost, hold, pen, base = cfg.PRODUCT_TEMPLATES[i % len(cfg.PRODUCT_TEMPLATES)]
        if i >= len(cfg.PRODUCT_TEMPLATES):
            name = f"{name} #{i // len(cfg.PRODUCT_TEMPLATES) + 1}"
        out.append(Product(name, lead, cost, hold, pen, base))
    return out


# --------------------------------------------------------------------------
# Planner state representation
# --------------------------------------------------------------------------
class PlanState(NamedTuple):
    """A node of the A* search tree (a NamedTuple is a hashable tuple).

    day      : absolute simulation day this state is *about to* be played
    stock    : total units on hand across warehouse + all stores
    pipeline : sorted tuple of (arrival_day, qty) for orders still in transit
    """
    day: int
    stock: int
    pipeline: Tuple[Tuple[int, int], ...]


@dataclass(frozen=True)
class PlanProblem:
    """A single-product planning problem handed to the planner."""
    product: Product
    start_day: int
    stock: int
    pipeline: Tuple[Tuple[int, int], ...]
    demand: Tuple[int, ...]      # forecast aggregate demand for days start_day, start_day+1, ...

    @property
    def end_day(self) -> int:
        return self.start_day + len(self.demand)

    @property
    def start_state(self) -> PlanState:
        return PlanState(self.start_day, self.stock, tuple(sorted(self.pipeline)))


@dataclass
class PlanResult:
    success: bool                       # False => node cap reached, no plan found
    orders: Dict[int, int]              # day -> quantity (non-zero orders only)
    cost: float                         # optimal planned cost (inf if not success)
    nodes_expanded: int
    path: List[PlanState]               # states along the optimal plan


@dataclass
class AllocationProblem:
    """Everything the allocator needs for one day (shapes: S stores, P products).

    day            : absolute simulation day being allocated
    wh_stock       : (P,)   units on hand in the warehouse (after today's arrivals)
    store_stock    : (S, P) units on hand in each store
    forecast       : (S, P) expected demand per store/product over the allocation
                     look-ahead window (cfg.ALLOC_LOOKAHEAD_DAYS days); this is
                     the "target" level the stores are topped up to
    truck_capacity : max total units (all products) that can be shipped today
    products       : the P products (cost parameters, used for penalty weighting)
    store_shares   : (S,)   share of system demand per store
    """
    day: int
    wh_stock: np.ndarray
    store_stock: np.ndarray
    forecast: np.ndarray
    truck_capacity: int
    products: List[Product]
    store_shares: np.ndarray

    def __post_init__(self) -> None:
        self.wh_stock = np.asarray(self.wh_stock, dtype=int)
        self.store_stock = np.asarray(self.store_stock, dtype=int)
        self.forecast = np.asarray(self.forecast, dtype=float)
        self.store_shares = np.asarray(self.store_shares, dtype=float)
        self.truck_capacity = int(self.truck_capacity)

    @property
    def num_stores(self) -> int:
        return int(self.store_stock.shape[0])

    @property
    def num_products(self) -> int:
        return int(self.store_stock.shape[1])

    @property
    def need(self) -> np.ndarray:
        """(S, P) units each store is short of its target level (never negative)."""
        return np.maximum(0.0, self.forecast - self.store_stock)

    @property
    def penalty(self) -> np.ndarray:
        """(P,) stock-out penalty per unit for every product."""
        return np.array([p.stockout_penalty for p in self.products], dtype=float)
