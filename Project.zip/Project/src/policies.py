"""Decision policies: each one maps the simulator state to (orders, allocation).

  * ReorderPointPolicy   - (s, S) baseline + proportional allocation
  * RulesAStarEqualPolicy - rules + A* + equal allocation        (ablation 1)
  * RulesAStarPropPolicy  - rules + A* + proportional allocation (ablation 2)
  * SmartStockPolicy      - rules + A* + genetic allocation      (full agent)
"""
from __future__ import annotations

import math
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Tuple

import numpy as np

import config as cfg
from .allocator import (Allocator, EqualAllocator, GeneticAllocator,
                        ProportionalAllocator)
from .models import AllocationProblem, PlanProblem
from .planners import AStarPlanner
from .rules import RuleEngine


# --------------------------------------------------------------------------
# Shared helpers
# --------------------------------------------------------------------------
def build_allocation_problem(env) -> AllocationProblem:
    """Snapshot of today's allocation problem.

    Supplier orders due today arrive BEFORE shipping (env step 1), so they are
    already counted in the warehouse stock the allocator sees.  `forecast` is
    the calendar-aware expected demand of the next ALLOC_LOOKAHEAD_DAYS days.
    """
    wh = env.wh_stock.copy()
    for arrival, p, q in env.pipeline:
        if arrival <= env.day:
            wh[p] += q
    forecast = np.zeros((env.num_stores, env.num_products))
    for d in range(env.day, min(env.horizon, env.day + cfg.ALLOC_LOOKAHEAD_DAYS)):
        forecast += env.gen.forecast(d)
    return AllocationProblem(env.day, wh, env.store_stock.copy(), forecast,
                             env.truck_capacity, env.products, env.store_shares)


def reorder_point_quantity(env, p: int, review_days: int) -> int:
    """(s, S) rule on the *average* demand (no calendar knowledge).

    s = base_demand * (lead_time + SAFETY_DAYS)      reorder point
    S = s + base_demand * review_days                 order-up-to level
    Order (S - position) rounded up to a multiple of ORDER_STEP when position <= s.
    """
    prod = env.products[p]
    s = prod.base_demand * (prod.lead_time + cfg.SAFETY_DAYS)
    S = s + prod.base_demand * review_days
    position = env.inventory_position(p)
    if position <= s:
        return int(math.ceil((S - position) / cfg.ORDER_STEP) * cfg.ORDER_STEP)
    return 0


class Policy(ABC):
    name = "Policy"

    def reset(self) -> None:
        """Clear per-episode state (called before every episode)."""

    @abstractmethod
    def decide(self, env) -> Tuple[np.ndarray, np.ndarray]:
        """Return (orders, allocation): orders shape (P,), allocation shape (S, P)."""

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.name!r})"


# --------------------------------------------------------------------------
# Main baseline
# --------------------------------------------------------------------------
class ReorderPointPolicy(Policy):
    """Classic reorder-point / order-up-to policy with proportional allocation."""
    name = "Reorder-Point"

    def __init__(self, review_days: int = 5):
        self.review_days = review_days
        self.allocator = ProportionalAllocator()

    def decide(self, env) -> Tuple[np.ndarray, np.ndarray]:
        orders = np.array([reorder_point_quantity(env, p, self.review_days)
                           for p in range(env.num_products)], dtype=int)
        allocation = self.allocator.allocate(build_allocation_problem(env))
        return orders, allocation


# --------------------------------------------------------------------------
# Rules + A* family
# --------------------------------------------------------------------------
class _PlanningPolicy(Policy):
    """Rule engine decides WHEN to re-plan, A* decides WHAT to order, an allocator
    decides WHERE the warehouse stock goes.  One rolling plan is kept per product."""

    def __init__(self, allocator: Allocator, rules: Optional[RuleEngine] = None,
                 planner: Optional[AStarPlanner] = None, fallback_review_days: int = 5):
        self.allocator = allocator
        self.rules = rules or RuleEngine()
        self.planner = planner or AStarPlanner(cache={})
        self.fallback_review_days = fallback_review_days
        self.reset()

    def reset(self) -> None:
        self.plans: Dict[int, Optional[Dict[int, int]]] = {}
        self.last_plan_day: Dict[int, Optional[int]] = {}
        self.stats = dict(replans=0, fallbacks=0, nodes=0)
        self.allocator.reset()

    # ---- planning -------------------------------------------------------
    def _replan(self, env, p: int) -> None:
        horizon = min(cfg.PLANNING_HORIZON, env.horizon - env.day)
        demand = tuple(int(round(env.gen.total_forecast(env.day + k)[p])) for k in range(horizon))
        problem = PlanProblem(product=env.products[p], start_day=env.day,
                              stock=env.total_stock(p), pipeline=env.pipeline_for(p),
                              demand=demand)
        result = self.planner.solve(problem)
        self.stats["replans"] += 1
        self.stats["nodes"] += result.nodes_expanded
        self.plans[p] = result.orders if result.success else None
        self.last_plan_day[p] = env.day

    def _order_today(self, env, p: int) -> int:
        replan, _ = self.rules.should_replan(env, p, self.last_plan_day.get(p))
        if replan and env.horizon - env.day > 0:
            self._replan(env, p)
        plan = self.plans.get(p)
        if plan is None:                      # node cap hit (or no plan yet) -> safe fallback
            self.stats["fallbacks"] += 1
            return reorder_point_quantity(env, p, self.fallback_review_days)
        return int(plan.get(env.day, 0))

    def decide(self, env) -> Tuple[np.ndarray, np.ndarray]:
        orders = np.array([self._order_today(env, p) for p in range(env.num_products)], dtype=int)
        allocation = self.allocator.allocate(build_allocation_problem(env))
        return orders, allocation


class RulesAStarEqualPolicy(_PlanningPolicy):
    """Ablation 1: rules + A* ordering, equal split to the stores."""
    name = "Rules+A*+Equal"

    def __init__(self, **kwargs):
        super().__init__(EqualAllocator(), **kwargs)


class RulesAStarPropPolicy(_PlanningPolicy):
    """Ablation 2: rules + A* ordering, proportional split to the stores."""
    name = "Rules+A*+Prop"

    def __init__(self, **kwargs):
        super().__init__(ProportionalAllocator(), **kwargs)


class SmartStockPolicy(_PlanningPolicy):
    """Full proposed agent: rules + A* ordering + genetic-algorithm allocation."""
    name = "SmartStock AI"

    def __init__(self, ga_seed: int = 0, **kwargs):
        self.ga_seed = ga_seed
        super().__init__(GeneticAllocator(seed=ga_seed), **kwargs)

    def reset(self) -> None:
        super().reset()
        self.ga_histories: List[List[float]] = []   # one fitness curve per GA call

    def decide(self, env) -> Tuple[np.ndarray, np.ndarray]:
        orders, allocation = super().decide(env)
        self.ga_histories.append(list(self.allocator.last_fitness_history))
        return orders, allocation
