"""Warehouse -> store allocators (pure Python + NumPy).

Every allocator maps an `AllocationProblem` to an integer array of shape (S, P):
units of product p shipped to store s today.

  * EqualAllocator        - split the warehouse stock equally across the stores
  * ProportionalAllocator - split it by the stores' demand shares
  * GeneticAllocator      - evolve an allocation that minimises expected
                            stock-out + holding cost (penalty-only constraints)
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, List, Optional

import numpy as np

import config as cfg
from .models import AllocationProblem


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def _split(total: int, weights: np.ndarray) -> np.ndarray:
    """Split an integer `total` by `weights` (largest-remainder method, sums exactly)."""
    w = np.asarray(weights, dtype=float)
    if total <= 0 or w.sum() <= 0:
        return np.zeros(len(w), dtype=int)
    raw = total * w / w.sum()
    out = np.floor(raw).astype(int)
    rem = int(total - out.sum())
    if rem > 0:
        order = np.argsort(-(raw - out), kind="stable")[:rem]
        out[order] += 1
    return out


def _fit_truck(alloc: np.ndarray, capacity: int) -> np.ndarray:
    """Scale an (S, P) allocation down proportionally so its total <= truck capacity."""
    capacity = max(int(capacity), 0)
    total = int(alloc.sum())
    if total <= capacity:
        return alloc
    scaled = alloc * (capacity / total)
    fl = np.floor(scaled).astype(int)
    rem = int(capacity - fl.sum())
    if rem > 0:
        idx = np.argsort(-(scaled - fl).ravel(), kind="stable")[:rem]
        flat = fl.ravel().copy()
        flat[idx] += 1
        fl = flat.reshape(alloc.shape)
    return np.minimum(fl, alloc)


class Allocator(ABC):
    name = "Allocator"

    def reset(self) -> None:
        """Clear any internal state (called at the start of every episode)."""

    @abstractmethod
    def allocate(self, problem: AllocationProblem) -> np.ndarray:
        """Return an integer (S, P) shipment plan."""


# --------------------------------------------------------------------------
# Baseline allocators
# --------------------------------------------------------------------------
class EqualAllocator(Allocator):
    """Every store gets the same share of each product's warehouse stock."""
    name = "Equal"

    def allocate(self, problem: AllocationProblem) -> np.ndarray:
        S, P = problem.num_stores, problem.num_products
        out = np.zeros((S, P), dtype=int)
        for p in range(P):
            out[:, p] = _split(int(problem.wh_stock[p]), np.ones(S))
        return _fit_truck(out, problem.truck_capacity)


class ProportionalAllocator(Allocator):
    """Each store gets a share of the warehouse stock equal to its demand share."""
    name = "Proportional"

    def allocate(self, problem: AllocationProblem) -> np.ndarray:
        S, P = problem.num_stores, problem.num_products
        out = np.zeros((S, P), dtype=int)
        for p in range(P):
            out[:, p] = _split(int(problem.wh_stock[p]), problem.store_shares)
        return _fit_truck(out, problem.truck_capacity)


# --------------------------------------------------------------------------
# Genetic algorithm
# --------------------------------------------------------------------------
class GeneticAllocator(Allocator):
    """Genetic algorithm over flattened (S*P) integer chromosomes.

    Chromosome : 1-D int array of length S*P (store-major: index s*P + p)
    Fitness    : -(expected_stockout_cost + expected_holding_cost)
                 - CONSTRAINT_PENALTY * (wh_excess + truck_excess)
      * expected demand per store/product = problem.forecast (look-ahead window)
      * stock-out cost = penalty_p * max(0, forecast - (store_stock + shipped))
      * holding cost   = holding_p * max(0, (store_stock + shipped) - forecast)
        (units pushed to a store beyond what it is expected to sell)
      * wh_excess   = units shipped beyond warehouse stock, summed over products
      * truck_excess = total shipped units beyond the truck capacity
    Constraints are handled ONLY through the penalty (no repair step); genes are
    merely bounded to [0, warehouse stock of their product].

    Operators: tournament selection, uniform crossover, integer-step mutation
    in [-mutation_step, +mutation_step], elitism, early stopping.
    `last_fitness_history` holds the best fitness of every generation of the
    most recent `allocate` call (used for the convergence chart).
    """
    name = "Genetic"

    def __init__(self, seed: int = 0, params: Optional[Dict] = None):
        self.seed = seed
        self.params = dict(cfg.GA_PARAMS, **(params or {}))
        self.rng = np.random.default_rng(seed)
        self.last_fitness_history: List[float] = []

    def reset(self) -> None:
        """Re-seed so every episode is reproducible for a given GA seed."""
        self.rng = np.random.default_rng(self.seed)
        self.last_fitness_history = []

    # ---- fitness ------------------------------------------------------
    @staticmethod
    def fitness(pop: np.ndarray, problem: AllocationProblem) -> np.ndarray:
        S, P = problem.num_stores, problem.num_products
        X = pop.reshape(len(pop), S, P)
        after = problem.store_stock[None, :, :] + X
        short = np.maximum(0.0, problem.forecast[None] - after)
        excess = np.maximum(0.0, after - problem.forecast[None])
        stockout_cost = (short * problem.penalty[None, None, :]).sum(axis=(1, 2))
        hold = np.array([p.holding_cost for p in problem.products])
        holding_cost = (excess * hold[None, None, :]).sum(axis=(1, 2))
        wh_excess = np.maximum(0, X.sum(axis=1) - problem.wh_stock[None, :]).sum(axis=1)
        truck_excess = np.maximum(0, X.sum(axis=(1, 2)) - problem.truck_capacity)
        return -(stockout_cost + holding_cost) - cfg.CONSTRAINT_PENALTY * (wh_excess + truck_excess)

    # ---- initial population -------------------------------------------
    def _need_seed(self, problem: AllocationProblem) -> np.ndarray:
        S, P = problem.num_stores, problem.num_products
        need = problem.need
        out = np.zeros((S, P), dtype=int)
        for p in range(P):
            wanted = np.ceil(need[:, p]).astype(int)
            if wanted.sum() <= problem.wh_stock[p]:
                out[:, p] = wanted
            else:
                out[:, p] = _split(int(problem.wh_stock[p]), need[:, p])
        return _fit_truck(out, problem.truck_capacity)

    def _random_individual(self, problem: AllocationProblem) -> np.ndarray:
        S, P = problem.num_stores, problem.num_products
        out = np.zeros((S, P), dtype=int)
        for p in range(P):
            total = int(round(self.rng.uniform(0.0, 1.0) * problem.wh_stock[p]))
            out[:, p] = _split(total, self.rng.dirichlet(np.ones(S)))
        return out

    def _initial_population(self, problem: AllocationProblem, ub: np.ndarray) -> np.ndarray:
        n = self.params["population_size"]
        seeds = [ProportionalAllocator().allocate(problem),
                 EqualAllocator().allocate(problem),
                 self._need_seed(problem)]
        pop = [s.ravel() for s in seeds[:n]]
        while len(pop) < n:
            pop.append(self._random_individual(problem).ravel())
        return np.clip(np.array(pop, dtype=int), 0, ub)

    # ---- main loop ----------------------------------------------------
    def allocate(self, problem: AllocationProblem) -> np.ndarray:
        S, P = problem.num_stores, problem.num_products
        wh = problem.wh_stock
        if wh.sum() <= 0 or problem.truck_capacity <= 0:
            self.last_fitness_history = [0.0]
            return np.zeros((S, P), dtype=int)

        prm = self.params
        N, L = prm["population_size"], S * P
        ub = np.tile(wh, S)                      # gene s*P+p is bounded by wh[p]
        pop = self._initial_population(problem, ub)

        history: List[float] = []
        best_fit, best_ind, stale = -np.inf, pop[0].copy(), 0

        for gen in range(prm["max_generations"] + 1):
            fit = self.fitness(pop, problem)
            order = np.argsort(-fit, kind="stable")
            gen_best = float(fit[order[0]])
            history.append(gen_best)
            if gen_best > best_fit + 1e-9:
                best_fit, best_ind, stale = gen_best, pop[order[0]].copy(), 0
            else:
                stale += 1
            if stale >= prm["early_stopping"] or gen == prm["max_generations"]:
                break

            # -- breed the next generation --------------------------------
            n_child = N - prm["elitism"]
            k = prm["tournament_size"]

            def tournament() -> np.ndarray:
                idx = self.rng.integers(0, N, size=(n_child, k))
                win = idx[np.arange(n_child), np.argmax(fit[idx], axis=1)]
                return pop[win]

            a, b = tournament(), tournament()
            do_cx = self.rng.random(n_child) < prm["crossover_rate"]
            gene_mask = self.rng.random((n_child, L)) < 0.5
            child = np.where(do_cx[:, None] & gene_mask, b, a)

            mut = self.rng.random((n_child, L)) < prm["mutation_rate"]
            step = self.rng.integers(-prm["mutation_step"], prm["mutation_step"] + 1,
                                     size=(n_child, L))
            child = np.clip(child + mut * step, 0, ub)

            pop = np.vstack([pop[order[:prm["elitism"]]], child])

        self.last_fitness_history = history
        return best_ind.reshape(S, P).astype(int)
