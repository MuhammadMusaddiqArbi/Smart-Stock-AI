"""RuleEngine: cheap IF-THEN monitoring that decides *when* to re-plan.

The expensive planner (A*) is only re-run when the rules say it is worth it:
  * LOW_STOCK     - inventory position fell to the reorder level
  * UPCOMING_SALE - a sale day falls inside the product's lead-time window
  * PERIODIC      - the plan is `refresh_every` days old
  * INITIAL       - no plan exists yet
This is the classic "rolling-horizon replanning" loop.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

import config as cfg


class RuleEngine:
    def __init__(self, refresh_every: int = cfg.RULE_REFRESH_DAYS,
                 safety_days: int = cfg.SAFETY_DAYS):
        self.refresh_every = refresh_every
        self.safety_days = safety_days

    # ---- calendar helpers -------------------------------------------------
    @staticmethod
    def event_uplift(env, day: int) -> float:
        """Calendar knowledge (delegates to the demand model)."""
        return env.gen.event_uplift(day)

    def upcoming_sale_days(self, env, p: int) -> List[int]:
        """Sale days inside today's lead-time window [today, today + lead_time + 1]."""
        lead = env.products[p].lead_time
        window = range(env.day, min(env.horizon, env.day + lead + 2))
        return [d for d in window if self.event_uplift(env, d) > 1.0]

    # ---- stock checks -----------------------------------------------------
    def reorder_level(self, env, p: int) -> float:
        """Forecast demand over (lead time + safety days): below this we are in danger."""
        days = env.products[p].lead_time + self.safety_days
        return sum(env.gen.total_forecast(env.day + k)[p] for k in range(days))

    def alerts(self, env, p: int) -> List[str]:
        out = []
        if env.inventory_position(p) <= self.reorder_level(env, p):
            out.append("LOW_STOCK")
        if self.upcoming_sale_days(env, p):
            out.append("UPCOMING_SALE")
        return out

    def should_replan(self, env, p: int, last_plan_day: Optional[int]) -> Tuple[bool, List[str]]:
        reasons = self.alerts(env, p)
        if last_plan_day is None:
            reasons.append("INITIAL")
        elif env.day - last_plan_day >= self.refresh_every:
            reasons.append("PERIODIC")
        return bool(reasons), reasons