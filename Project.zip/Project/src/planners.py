"""A* and Uniform-Cost planners for single-product replenishment.

The planner works on ONE product at a time, using the aggregate system stock
(warehouse + all stores) and the aggregate forecast demand.  Allocation to the
individual stores is a separate problem (see allocator.py).
"""
from __future__ import annotations

import heapq
import itertools
from typing import Dict, Optional, Sequence, Tuple

import config as cfg
from .models import PlanProblem, PlanResult, PlanState


class AStarPlanner:
    """Optimal replenishment planning with A* search.

    Search space
    ------------
    state   : PlanState(day, total_stock, pipeline)   (hashable -> closed set)
    action  : order q in {0, 10, ..., 100} units today (arrives day + lead_time)
    step    : (1) arrivals due today join the stock, (2) the order is placed,
              (3) forecast demand is served; unmet demand is lost
    cost g  : ordering_cost + holding_cost * ending_stock
              + stockout_penalty * unmet_forecast_demand
              (ordering_cost = fixed_fee + unit_cost * q  if q > 0)
    goal    : day == start_day + horizon (no salvage value for leftover stock)

    Heuristic
    ---------
        uncovered_demand = max(0, remaining_forecast_demand - (stock + pipeline_stock))
        h(s)             = uncovered_demand * min(unit_cost, stockout_penalty)

    Admissibility proof (plain English)
    -----------------------------------
    Every unit of `uncovered_demand` cannot be served from stock we already
    have or have already ordered.  So, from state s onward, each such unit must
    either (a) be bought from the supplier, costing at least `unit_cost`, or
    (b) be lost, costing exactly `stockout_penalty`.  Whichever happens, it
    costs at least min(unit_cost, stockout_penalty).  The true remaining cost
    h*(s) pays all of that PLUS things h ignores: the $50 fixed fee of every
    order, all holding costs, and any extra cost of poor timing.  All ignored
    terms are >= 0, therefore h(s) <= h*(s): the heuristic never overestimates,
    and A* with it returns an optimal plan.  (It is also consistent: an order of
    q units lowers h by at most unit_cost*q, and a day's unmet demand lowers it
    by at most penalty*unmet - and each of those is paid for in g.)

    Optional performance trick: results can be memoised in a shared `cache`
    dict - identical planning problems (same state, same forecast) then cost
    nothing the second time.  Pass cache=None to disable it.
    """

    name = "A*"

    def __init__(self, order_quantities: Sequence[int] = cfg.ORDER_QUANTITIES,
                 node_cap: int = cfg.NODE_CAP, fixed_fee: float = cfg.FIXED_ORDER_FEE,
                 cache: Optional[dict] = None):
        self.order_quantities = tuple(order_quantities)
        self.node_cap = node_cap
        self.fixed_fee = fixed_fee
        self.cache = cache
        self._problem: Optional[PlanProblem] = None
        self._suffix: Sequence[int] = ()

    # ------------------------------------------------------------------
    def prepare(self, problem: PlanProblem) -> None:
        """Pre-compute suffix sums so 'remaining forecast demand' is an O(1) lookup."""
        self._problem = problem
        d = problem.demand
        suffix = [0] * (len(d) + 1)
        for i in range(len(d) - 1, -1, -1):
            suffix[i] = suffix[i + 1] + int(d[i])
        self._suffix = suffix
        self._min_unit = min(problem.product.unit_cost, problem.product.stockout_penalty)

    # ------------------------------------------------------------------
    def heuristic(self, state: PlanState) -> float:
        """Admissible lower bound on the remaining cost (see class docstring)."""
        p = self._problem
        remaining = self._suffix[min(state.day - p.start_day, len(self._suffix) - 1)]
        in_transit = sum(q for _, q in state.pipeline)
        uncovered = max(0, remaining - (state.stock + in_transit))
        return uncovered * self._min_unit

    # ------------------------------------------------------------------
    def _successors(self, state: PlanState):
        """Yield (q, next_state, step_cost) for every allowed order quantity."""
        p = self._problem
        prod = p.product
        end_day = p.end_day
        day = state.day

        # (1) arrivals due today join the stock
        stock = state.stock
        waiting: Dict[int, int] = {}
        for arrival, qty in state.pipeline:
            if arrival <= day:
                stock += qty
            else:
                waiting[arrival] = waiting.get(arrival, 0) + qty

        # (3) forecast demand is served (identical for every action)
        demand = int(p.demand[day - p.start_day])
        served = min(stock, demand)
        unmet = demand - served
        ending = stock - served
        base_cost = prod.holding_cost * ending + prod.stockout_penalty * unmet

        for q in self.order_quantities:
            pipe = waiting
            cost = base_cost
            if q > 0:
                arrival = day + prod.lead_time
                if arrival >= end_day:
                    continue          # would arrive after the horizon: pure waste (no salvage)
                pipe = dict(waiting)
                pipe[arrival] = pipe.get(arrival, 0) + q
                cost += self.fixed_fee + prod.unit_cost * q
            yield q, PlanState(day + 1, ending, tuple(sorted(pipe.items()))), cost

    # ------------------------------------------------------------------
    def solve(self, problem: Optional[PlanProblem] = None) -> PlanResult:
        """Search for the cheapest order plan; give up after `node_cap` expansions."""
        if problem is not None:
            self.prepare(problem)
        if self._problem is None:
            raise RuntimeError("Call prepare(problem) or solve(problem) first.")
        problem = self._problem

        key = None
        if self.cache is not None:
            key = (self.name, problem.product.key(), problem.start_state, problem.demand,
                   self.order_quantities, self.fixed_fee, self.node_cap)
            if key in self.cache:
                return self.cache[key]

        result = self._search(problem)
        if key is not None:
            self.cache[key] = result
        return result

    def _search(self, problem: PlanProblem) -> PlanResult:
        start = problem.start_state
        end_day = problem.end_day
        counter = itertools.count()
        h0 = self.heuristic(start)
        frontier = [(h0, h0, next(counter), 0.0, start)]    # (f, h, tie, g, state)
        best_g: Dict[PlanState, float] = {start: 0.0}
        parent: Dict[PlanState, Tuple[Optional[PlanState], int]] = {start: (None, 0)}
        expanded = 0

        while frontier:
            f, _, _, g, state = heapq.heappop(frontier)
            if g > best_g.get(state, float("inf")) + 1e-12:
                continue                                     # stale queue entry
            if state.day >= end_day:
                return self._build_result(state, g, parent, expanded)
            if expanded >= self.node_cap:
                break
            expanded += 1

            for q, nxt, step_cost in self._successors(state):
                ng = g + step_cost
                if ng < best_g.get(nxt, float("inf")) - 1e-12:
                    best_g[nxt] = ng
                    parent[nxt] = (state, q)
                    h = self.heuristic(nxt)
                    heapq.heappush(frontier, (ng + h, h, next(counter), ng, nxt))

        return PlanResult(False, {}, float("inf"), expanded, [])

    @staticmethod
    def _build_result(goal: PlanState, cost: float, parent: dict, expanded: int) -> PlanResult:
        path = []
        orders: Dict[int, int] = {}
        state: Optional[PlanState] = goal
        while state is not None:
            path.append(state)
            prev, q = parent[state]
            if prev is not None and q > 0:
                orders[prev.day] = q
            state = prev
        path.reverse()
        return PlanResult(True, dict(sorted(orders.items())), float(cost), expanded, path)


class UniformCostPlanner(AStarPlanner):
    """Same search with h = 0 (Dijkstra / UCS): optimal but expands more nodes."""

    name = "UCS"

    def heuristic(self, state: PlanState) -> float:
        return 0.0
