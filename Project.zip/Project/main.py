"""SmartStock AI - command-line entry point (place in the project root, next to config.py).

Examples
--------
  python main.py data                          # generate / verify the 30 cached demand CSVs
  python main.py demo --policy smartstock --scenario 21
  python main.py quick                         # fast smoke test (3 scenarios, 1 GA seed)
  python main.py full                          # everything: tables + 5 charts
  python main.py full --scenarios 1 11 21 --ga-seeds 0 1
"""
from __future__ import annotations

import argparse
import sys
import time

import config as cfg
from src.demand import ensure_all_scenarios, scenario_kind
from src.evaluator import Evaluator, run_episode
from src.policies import (ReorderPointPolicy, RulesAStarEqualPolicy,
                          RulesAStarPropPolicy, SmartStockPolicy)

POLICIES = {
    "reorder": lambda seed: ReorderPointPolicy(),
    "astar-equal": lambda seed: RulesAStarEqualPolicy(),
    "astar-prop": lambda seed: RulesAStarPropPolicy(),
    "smartstock": lambda seed: SmartStockPolicy(ga_seed=seed),
}


def cmd_data(args) -> None:
    paths = ensure_all_scenarios()
    print(f"{len(paths)} scenario files ready in {cfg.DATA_DIR}")


def cmd_demo(args) -> None:
    ensure_all_scenarios()
    policy = POLICIES[args.policy](args.ga_seeds[0] if args.ga_seeds else 0)
    t0 = time.time()
    summary, env = run_episode(policy, args.scenario, args.truck, args.penalty)
    print(f"\nPolicy   : {policy.name}")
    print(f"Scenario : {args.scenario} ({scenario_kind(args.scenario)}), "
          f"truck={args.truck}, penalty x{args.penalty}")
    print("-" * 40)
    for key, val in summary.items():
        print(f"{key:<15}: {val:,.4f}" if isinstance(val, float) else f"{key:<15}: {val}")
    stats = getattr(policy, "stats", None)
    if stats:
        print(f"{'planner stats':<15}: {stats}")
    print(f"{'runtime (s)':<15}: {time.time() - t0:.1f}")


def cmd_run(args, quick: bool = False) -> None:
    ensure_all_scenarios()
    scenarios = args.scenarios or ([1, 11, 21] if quick else None)
    ga_seeds = args.ga_seeds or ([0] if quick else None)
    t0 = time.time()
    Evaluator(scenarios=scenarios, ga_seeds=ga_seeds).run()
    print(f"\nDone in {time.time() - t0:.0f}s.")
    print(f"Tables : {cfg.RESULTS_DIR / 'summary_metrics.csv'}, {cfg.RESULTS_DIR / 'detailed_runs.csv'}")
    print(f"Charts : {cfg.CHARTS_DIR}")


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="SmartStock AI - intelligent inventory replenishment agent")
    sub = ap.add_subparsers(dest="command", required=True)

    sub.add_parser("data", help="generate the 30 demand scenarios as CSV")

    demo = sub.add_parser("demo", help="run ONE episode and print its metrics")
    demo.add_argument("--policy", choices=POLICIES, default="smartstock")
    demo.add_argument("--scenario", type=int, default=1)
    demo.add_argument("--truck", type=int, default=cfg.TRUCK_CAPACITY)
    demo.add_argument("--penalty", type=float, default=1.0, help="stock-out penalty multiplier")
    demo.add_argument("--ga-seeds", type=int, nargs="+", help="first value is used as the GA seed")

    for name, text in (("quick", "fast smoke test (scenarios 1, 11, 21; one GA seed)"),
                       ("full", "all policies x all scenarios, CSV tables and 5 charts")):
        p = sub.add_parser(name, help=text)
        p.add_argument("--scenarios", type=int, nargs="+", help="scenario ids (default: all 30)")
        p.add_argument("--ga-seeds", type=int, nargs="+", help=f"default: {list(cfg.GA_SEEDS)}")
    return ap


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "data":
        cmd_data(args)
    elif args.command == "demo":
        cmd_demo(args)
    elif args.command == "quick":
        cmd_run(args, quick=True)
    else:
        cmd_run(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
