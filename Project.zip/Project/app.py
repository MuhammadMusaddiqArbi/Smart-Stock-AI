"""SmartStock AI - interactive Streamlit dashboard (place in the project root, next to config.py).

    streamlit run app.py

Tab 1  Live simulation sandbox : run one 90-day episode with any policy / scenario.
Tab 2  Benchmark & ablation    : results of `python main.py full` (CSV table + 5 charts).
"""
from __future__ import annotations

import time
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import config as cfg
from src.demand import ensure_all_scenarios, scenario_kind
from src.evaluator import run_episode
from src.policies import (Policy, ReorderPointPolicy, RulesAStarEqualPolicy,
                          RulesAStarPropPolicy, SmartStockPolicy)

st.set_page_config(page_title="SmartStock AI", page_icon="📦", layout="wide")

POLICY_FACTORIES = {
    "SmartStockPolicy  (Rules + A* + Genetic)": lambda: SmartStockPolicy(ga_seed=cfg.GA_SEEDS[0]),
    "RulesAStarPropPolicy  (Rules + A* + Proportional)": lambda: RulesAStarPropPolicy(),
    "RulesAStarEqualPolicy  (Rules + A* + Equal)": lambda: RulesAStarEqualPolicy(),
    "ReorderPointPolicy  (s, S baseline)": lambda: ReorderPointPolicy(),
}

CHART_FILES = [
    ("chart1_total_cost.png", "Chart 1 - Total cost per policy"),
    ("chart2_fill_rate_vs_inventory.png", "Chart 2 - Fill rate vs. average inventory"),
    ("chart3_astar_vs_ucs.png", "Chart 3 - A* vs. Uniform-Cost search effort"),
    ("chart4_ga_convergence.png", "Chart 4 - GA convergence"),
    ("chart5_sensitivity_penalty.png", "Chart 5 - Sensitivity to the stock-out penalty"),
]


# --------------------------------------------------------------------------
# Simulation helper
# --------------------------------------------------------------------------
class _Recorder(Policy):
    """Transparent wrapper that snapshots warehouse / store stock for every day.

    `run_episode` (src/evaluator.py) only returns the final env, whose history
    holds TOTAL inventory.  `decide()` is called at the start of each day, when
    the stock levels equal the previous day's closing levels, so the snapshots
    (shifted by one day + the final env state) give closing warehouse / store
    levels without touching the simulator.
    """

    def __init__(self, inner: Policy):
        self.inner = inner
        self.name = inner.name
        self.opening: List[Tuple[np.ndarray, np.ndarray]] = []

    def reset(self) -> None:
        self.inner.reset()
        self.opening = []

    def decide(self, env):
        self.opening.append((env.wh_stock.copy(), env.store_stock.copy()))
        return self.inner.decide(env)


@st.cache_data(show_spinner=False)
def simulate(policy_label: str, scenario: int, truck: int, penalty: float) -> Dict:
    """Run one full episode with the evaluator's own `run_episode`."""
    ensure_all_scenarios()
    rec = _Recorder(POLICY_FACTORIES[policy_label]())
    t0 = time.time()
    summary, env = run_episode(rec, scenario, truck_capacity=truck, penalty_multiplier=penalty)
    runtime = time.time() - t0

    closing = rec.opening[1:] + [(env.wh_stock.copy(), env.store_stock.copy())]
    rows = []
    for h, (wh, stores) in zip(env.history, closing):
        row = dict(day=h["day"] + 1, warehouse=int(wh.sum()),
                   demand=h["demand"], lost_units=h["unmet"], shipped=h["shipped"],
                   ordering=h["ordering"], holding=h["holding"], stockout=h["stockout"],
                   cost=h["cost"])
        for s in range(stores.shape[0]):
            row[f"Store {s + 1}"] = int(stores[s].sum())
        rows.append(row)
    df = pd.DataFrame(rows)
    df["cumulative_cost"] = df["cost"].cumsum()
    df["cum_ordering"] = df["ordering"].cumsum()
    df["cum_holding"] = df["holding"].cumsum()
    df["cum_stockout"] = df["stockout"].cumsum()
    return dict(summary=summary, daily=df, runtime=runtime, num_stores=env.num_stores,
                stats=getattr(rec.inner, "stats", None))


# --------------------------------------------------------------------------
# Plot helpers
# --------------------------------------------------------------------------
def _layout(fig: go.Figure, title: str, ytitle: str) -> go.Figure:
    fig.update_layout(title=title, xaxis_title="Day", yaxis_title=ytitle,
                      hovermode="x unified", height=380, margin=dict(l=10, r=10, t=50, b=10),
                      legend=dict(orientation="h", yanchor="bottom", y=1.02, x=0))
    return fig


def inventory_fig(df: pd.DataFrame, n_stores: int) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df.day, y=df.warehouse, name="Warehouse",
                             mode="lines", stackgroup="inv"))
    for s in range(n_stores):
        fig.add_trace(go.Scatter(x=df.day, y=df[f"Store {s + 1}"], name=f"Store {s + 1}",
                                 mode="lines", stackgroup="inv"))
    return _layout(fig, "Closing inventory by location (stacked, all products)", "Units on hand")


def lost_sales_fig(df: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Bar(x=df.day, y=df.lost_units, name="Lost units (stock-out)",
                         marker_color="crimson"))
    fig.add_trace(go.Scatter(x=df.day, y=df.demand, name="Total demand", mode="lines",
                             line=dict(color="gray", dash="dot")))
    return _layout(fig, "Daily lost sales vs. demand", "Units")


def cost_fig(df: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df.day, y=df.cumulative_cost, name="Total", mode="lines",
                             line=dict(width=3)))
    for col, label in (("cum_ordering", "Ordering"), ("cum_holding", "Holding"),
                       ("cum_stockout", "Stock-out")):
        fig.add_trace(go.Scatter(x=df.day, y=df[col], name=label, mode="lines",
                                 line=dict(dash="dash")))
    return _layout(fig, "Cumulative cost", "Cost ($)")


# --------------------------------------------------------------------------
# Sidebar (controls apply to Tab 1)
# --------------------------------------------------------------------------
st.title("📦 SmartStock AI")
st.caption("An intelligent inventory replenishment agent - rules + A* planning + genetic-algorithm allocation")

with st.sidebar:
    st.header("Simulation controls")
    st.caption("These settings drive the **Live Simulation Sandbox** tab.")
    scenario = st.number_input("Scenario seed (1-31)", min_value=1, max_value=31,
                               value=1, step=1)
    st.caption(f"Demand type: **{scenario_kind(int(scenario))}**")
    policy_label = st.selectbox("Policy", list(POLICY_FACTORIES))
    truck = st.slider("Truck capacity (units/day)", min_value=50, max_value=600,
                      value=int(cfg.TRUCK_CAPACITY), step=10)
    penalty = st.slider("Stock-out penalty multiplier", min_value=0.5, max_value=10.0,
                        value=1.0, step=0.5)
    run_clicked = st.button("▶ Run 90-day episode", type="primary", use_container_width=True)
    st.caption("SmartStock AI runs A* and a GA every day, so it can take a while; "
               "finished runs are cached.")

tab_live, tab_bench = st.tabs(["🧪 Live Simulation Sandbox", "📊 31-Scenario Benchmark & Ablation"])

# --------------------------------------------------------------------------
# Tab 1 - live simulation
# --------------------------------------------------------------------------
with tab_live:
    params = (policy_label, int(scenario), int(truck), float(penalty))
    if run_clicked:
        with st.spinner(f"Simulating {cfg.SIM_DAYS} days with {policy_label.split()[0]} ..."):
            st.session_state["live_result"] = (params, simulate(*params))

    stored = st.session_state.get("live_result")
    if stored is None:
        st.info("Choose a scenario, policy, truck capacity and penalty in the sidebar, "
                "then press **Run 90-day episode**.")
    else:
        used, res = stored
        if used != params:
            st.warning("Sidebar settings changed since this run - press **Run 90-day episode** "
                       "to refresh. Showing the previous run:")
        pol, scen, trk, pen = used
        st.subheader(f"{pol.split()[0]} - scenario {scen} ({scenario_kind(scen)}), "
                     f"truck {trk}, penalty x{pen:g}")

        s = res["summary"]
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total Cost", f"${s['total_cost']:,.0f}")
        c2.metric("Fill Rate", f"{100 * s['fill_rate']:.2f}%")
        c3.metric("Average Inventory", f"{s['avg_inventory']:,.0f} units")
        c4.metric("Stock-Out Days", f"{s['stockout_days']}")

        d1, d2, d3, d4 = st.columns(4)
        d1.metric("Ordering cost", f"${s['ordering_cost']:,.0f}")
        d2.metric("Holding cost", f"${s['holding_cost']:,.0f}")
        d3.metric("Stock-out cost", f"${s['stockout_cost']:,.0f}")
        d4.metric("Lost units", f"{s['lost_units']:,}")
        st.caption(f"{s['num_orders']} supplier orders - runtime {res['runtime']:.1f}s"
                   + (f" - planner stats: {res['stats']}" if res["stats"] else ""))

        df = res["daily"]
        st.plotly_chart(inventory_fig(df, res["num_stores"]), use_container_width=True)
        left, right = st.columns(2)
        left.plotly_chart(lost_sales_fig(df), use_container_width=True)
        right.plotly_chart(cost_fig(df), use_container_width=True)

        with st.expander("Daily data"):
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.download_button("Download daily data (CSV)", df.to_csv(index=False).encode(),
                               file_name=f"episode_s{scen}.csv", mime="text/csv")

# --------------------------------------------------------------------------
# Tab 2 - benchmark results
# --------------------------------------------------------------------------
with tab_bench:
    summary_path = cfg.RESULTS_DIR / "summary_metrics.csv"
    chart_paths = [(cfg.CHARTS_DIR / f, cap) for f, cap in CHART_FILES]
    have_table = summary_path.exists()
    missing = [p.name for p, _ in chart_paths if not p.exists()]

    if not have_table or missing:
        st.info("Some benchmark outputs have not been generated yet. "
                "Run the full pipeline from the project root, then refresh this page:")
        st.code("python main.py full", language="bash")
        st.caption("Quick smoke test: `python main.py quick`.")
        if missing:
            st.caption("Missing charts: " + ", ".join(missing))

    st.subheader("Summary metrics (mean ± std across scenarios)")
    if have_table:
        summary = pd.read_csv(summary_path)
        kinds = ["all"] + [k for k in cfg.SCENARIO_KINDS]
        pick = st.radio("Scenario type", kinds, horizontal=True)
        shown_cols = ["policy", "scenario_type", "n_scenarios", "total_cost", "ordering_cost",
                      "holding_cost", "stockout_cost", "fill_rate_pct", "avg_inventory",
                      "stockout_days"]
        shown_cols = [c for c in shown_cols if c in summary.columns]
        st.dataframe(summary[summary["scenario_type"] == pick][shown_cols],
                     use_container_width=True, hide_index=True)
        with st.expander("Full summary table"):
            st.dataframe(summary, use_container_width=True, hide_index=True)
    else:
        st.caption(f"Expected file: `{summary_path}`")

    st.subheader("Charts")
    for i in range(0, len(chart_paths), 2):
        cols = st.columns(2)
        for col, (path, caption) in zip(cols, chart_paths[i:i + 2]):
            with col:
                if path.exists():
                    st.image(str(path), caption=caption, use_container_width=True)
                else:
                    st.warning(f"`{path.name}` not found.")
