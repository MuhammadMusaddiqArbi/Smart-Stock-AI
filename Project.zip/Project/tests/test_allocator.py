"""Unit tests for the warehouse -> store allocators (src/allocator.py).

Run from the project root:   pytest tests/test_allocator.py -v
"""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config as cfg  # noqa: E402
from src.allocator import (EqualAllocator, GeneticAllocator,  # noqa: E402
                           ProportionalAllocator)
from src.models import AllocationProblem, default_products  # noqa: E402

# Smaller budget than production so the whole file runs in a few seconds.
FAST_GA = dict(population_size=40, max_generations=60, early_stopping=15)


def make_problem(truck_capacity: int = cfg.TRUCK_CAPACITY, wh_scale: float = 1.0,
                 seed: int = 0) -> AllocationProblem:
    rng = np.random.default_rng(seed)
    products = default_products()
    shares = np.asarray(cfg.STORE_SHARES, dtype=float)
    base = np.array([p.base_demand for p in products], dtype=float)

    forecast = 2.0 * np.outer(shares, base)                      # 2-day look-ahead (S, P)
    store_stock = rng.integers(0, 40, size=forecast.shape)       # (S, P)
    wh_stock = np.rint(wh_scale * 3 * base).astype(int)          # (P,)
    return AllocationProblem(day=0, wh_stock=wh_stock, store_stock=store_stock,
                             forecast=forecast, truck_capacity=truck_capacity,
                             products=products, store_shares=shares)


def assert_feasible(plan: np.ndarray, problem: AllocationProblem) -> None:
    S, P = problem.num_stores, problem.num_products
    assert plan.shape == (S, P)
    assert np.issubdtype(plan.dtype, np.integer)
    assert (plan >= 0).all(), "negative shipment"
    # per-product warehouse stock limit
    assert (plan.sum(axis=0) <= problem.wh_stock).all(), (
        f"warehouse limit violated: shipped {plan.sum(axis=0)}, stock {problem.wh_stock}")
    # cross-product daily truck capacity
    assert plan.sum() <= problem.truck_capacity, (
        f"truck capacity violated: {plan.sum()} > {problem.truck_capacity}")


# --------------------------------------------------------------------------
# Constraint satisfaction
# --------------------------------------------------------------------------
@pytest.mark.parametrize("truck_capacity", [30, 100, 250, 1000])
@pytest.mark.parametrize("ga_seed", [0, 1, 2])
def test_ga_respects_warehouse_and_truck_limits(truck_capacity, ga_seed):
    problem = make_problem(truck_capacity=truck_capacity)
    plan = GeneticAllocator(seed=ga_seed, params=FAST_GA).allocate(problem)
    assert_feasible(plan, problem)


def test_ga_respects_limits_when_warehouse_is_scarce():
    problem = make_problem(truck_capacity=250, wh_scale=0.2)
    plan = GeneticAllocator(seed=0, params=FAST_GA).allocate(problem)
    assert_feasible(plan, problem)


def test_ga_returns_zero_plan_for_empty_warehouse():
    problem = make_problem()
    problem.wh_stock = np.zeros_like(problem.wh_stock)
    plan = GeneticAllocator(seed=0, params=FAST_GA).allocate(problem)
    assert plan.shape == (problem.num_stores, problem.num_products)
    assert plan.sum() == 0


def test_ga_returns_zero_plan_for_zero_truck():
    problem = make_problem(truck_capacity=0)
    plan = GeneticAllocator(seed=0, params=FAST_GA).allocate(problem)
    assert plan.sum() == 0


def test_baseline_allocators_are_feasible():
    problem = make_problem(truck_capacity=100)
    for allocator in (EqualAllocator(), ProportionalAllocator()):
        assert_feasible(allocator.allocate(problem), problem)


# --------------------------------------------------------------------------
# Fitness behaviour
# --------------------------------------------------------------------------
@pytest.mark.parametrize("ga_seed", [0, 1, 2])
def test_ga_fitness_does_not_decrease(ga_seed):
    problem = make_problem(truck_capacity=120)
    ga = GeneticAllocator(seed=ga_seed, params=FAST_GA)
    ga.allocate(problem)
    history = ga.last_fitness_history

    assert len(history) >= 1
    assert history[-1] >= history[0]
    # elitism => the best-of-generation curve is monotone non-decreasing
    assert all(b >= a - 1e-9 for a, b in zip(history, history[1:]))


def test_ga_is_at_least_as_good_as_its_baseline_seeds():
    problem = make_problem(truck_capacity=120)
    ga = GeneticAllocator(seed=0, params=FAST_GA)
    plan = ga.allocate(problem)

    def fit(x):
        return float(GeneticAllocator.fitness(x.ravel()[None, :], problem)[0])

    assert fit(plan) >= fit(ProportionalAllocator().allocate(problem)) - 1e-9
    assert fit(plan) >= fit(EqualAllocator().allocate(problem)) - 1e-9


def test_ga_is_reproducible_after_reset():
    problem = make_problem(truck_capacity=120)
    ga = GeneticAllocator(seed=3, params=FAST_GA)
    first = ga.allocate(problem)
    ga.reset()
    second = ga.allocate(problem)
    np.testing.assert_array_equal(first, second)
