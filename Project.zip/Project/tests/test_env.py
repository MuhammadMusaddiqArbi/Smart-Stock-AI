"""Unit tests for the InventoryEnv simulator (src/env.py).

Run from the project root:   pytest tests/test_env.py -v
"""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config as cfg  # noqa: E402
from src.env import InventoryEnv  # noqa: E402

DAYS = 30            # short episodes keep the tests fast
SCENARIOS = [1, 11, 21]   # one steady, one weekly, one sale scenario


@pytest.fixture
def make_env(tmp_path):
    """Factory building an env that caches its demand CSVs in a temp dir."""
    def _make(scenario: int = 1, **kwargs) -> InventoryEnv:
        kwargs.setdefault("horizon", DAYS)
        return InventoryEnv(data_dir=tmp_path, **kwargs).reset(scenario)
    return _make


def random_actions(env: InventoryEnv, rng: np.random.Generator):
    """A random (but valid-shaped) order vector and (S, P) shipment request."""
    orders = rng.choice(cfg.ORDER_QUANTITIES, size=env.num_products)
    allocation = rng.integers(0, 40, size=(env.num_stores, env.num_products))
    return orders, allocation


# --------------------------------------------------------------------------
# reset()
# --------------------------------------------------------------------------
def test_reset_initial_state(make_env):
    env = make_env(1)
    base = np.array([p.base_demand for p in env.products])

    assert env.day == 0 and not env.done
    assert env.scenario_id == 1
    assert env.num_products == cfg.NUM_PRODUCTS
    assert env.num_stores == cfg.NUM_STORES
    np.testing.assert_array_equal(env.wh_stock, np.rint(cfg.INITIAL_WAREHOUSE_DAYS * base).astype(int))
    np.testing.assert_array_equal(env.store_stock, np.rint(cfg.INITIAL_STORE_DAYS * env.gen.base).astype(int))
    assert env.store_stock.shape == (cfg.NUM_STORES, cfg.NUM_PRODUCTS)
    assert env.pipeline == [] and env.history == []
    assert all(v == 0 for v in env.totals.values())


def test_reset_clears_previous_episode(make_env):
    env = make_env(1)
    rng = np.random.default_rng(0)
    for _ in range(5):
        env.step(*random_actions(env, rng))
    assert env.day == 5

    env.reset(2)
    assert env.day == 0 and env.scenario_id == 2
    assert env.history == [] and env.pipeline == []
    assert env.totals["ordering"] == 0.0 and env.totals["demand_units"] == 0


def test_reset_is_deterministic(make_env):
    a, b = make_env(11), make_env(11)
    np.testing.assert_array_equal(a._demand, b._demand)
    np.testing.assert_array_equal(a.wh_stock, b.wh_stock)
    assert a._demand.shape == (DAYS, cfg.NUM_STORES, cfg.NUM_PRODUCTS)


def test_penalty_multiplier_scales_product_penalties(make_env):
    base, scaled = make_env(1), make_env(1, penalty_multiplier=5.0)
    np.testing.assert_allclose(scaled.penalty, 5.0 * base.penalty)


def test_step_after_done_raises(make_env):
    env = make_env(1, horizon=3)
    for _ in range(3):
        env.step()
    assert env.done
    with pytest.raises(RuntimeError):
        env.step()


# --------------------------------------------------------------------------
# Inventory conservation:  starting_stock + arrivals - sales == ending_stock
# --------------------------------------------------------------------------
@pytest.mark.parametrize("scenario", SCENARIOS)
def test_daily_inventory_conservation(make_env, scenario):
    """Warehouse -> store shipments are internal, so system stock only changes
    through supplier arrivals (+) and sales (-)."""
    env = make_env(scenario)
    rng = np.random.default_rng(scenario)

    while not env.done:
        start_stock = int(env.wh_stock.sum() + env.store_stock.sum())
        # orders placed today always have lead_time >= 1, so only the existing
        # pipeline can arrive today
        arrivals = sum(q for (arr, _, q) in env.pipeline if arr <= env.day)

        info = env.step(*random_actions(env, rng))

        sales = info["demand"] - info["unmet"]
        end_stock = int(env.wh_stock.sum() + env.store_stock.sum())
        assert start_stock + arrivals - sales == end_stock
        assert info["inventory"] == end_stock


@pytest.mark.parametrize("scenario", SCENARIOS)
def test_per_product_conservation(make_env, scenario):
    env = make_env(scenario)
    rng = np.random.default_rng(100 + scenario)

    while not env.done:
        start = env.wh_stock + env.store_stock.sum(axis=0)
        arrivals = np.zeros(env.num_products, dtype=int)
        for arr, p, q in env.pipeline:
            if arr <= env.day:
                arrivals[p] += q
        demand = env._demand[env.day].sum(axis=0)

        env.step(*random_actions(env, rng))

        end = env.wh_stock + env.store_stock.sum(axis=0)
        sold = start + arrivals - end                   # implied per-product sales
        assert (sold >= 0).all()
        assert (sold <= demand).all()                   # can never sell more than demanded


def test_stock_never_negative(make_env):
    env = make_env(21)
    rng = np.random.default_rng(7)
    while not env.done:
        env.step(*random_actions(env, rng))
        assert (env.wh_stock >= 0).all() and (env.store_stock >= 0).all()


# --------------------------------------------------------------------------
# Lost-sales accounting:  sales + unmet_demand == realized_demand
# --------------------------------------------------------------------------
@pytest.mark.parametrize("scenario", SCENARIOS)
def test_sales_plus_unmet_equals_realized_demand(make_env, scenario):
    env = make_env(scenario)
    rng = np.random.default_rng(scenario)

    while not env.done:
        day = env.day
        realized = int(env._demand[day].sum())
        info = env.step(*random_actions(env, rng))

        assert info["demand"] == realized
        assert 0 <= info["unmet"] <= info["demand"]
        assert (info["demand"] - info["unmet"]) + info["unmet"] == realized

    t = env.totals
    assert t["sold_units"] + t["lost_units"] == t["demand_units"]
    assert t["demand_units"] == int(env._demand.sum())
    assert t["demand_units"] == sum(h["demand"] for h in env.history)
    assert t["lost_units"] == sum(h["unmet"] for h in env.history)


def test_no_stock_means_everything_is_lost(make_env):
    env = make_env(1)
    env.wh_stock[:] = 0
    env.store_stock[:] = 0
    info = env.step()                                   # no orders, no shipment

    assert info["unmet"] == info["demand"] == int(env._demand[0].sum())
    expected = float(np.sum(env.penalty * env._demand[0].sum(axis=0)))
    assert info["stockout"] == pytest.approx(expected)
    s = env.summary()
    assert s["fill_rate"] == 0.0 and s["stockout_days"] == 1


def test_plentiful_stock_means_no_lost_sales(make_env):
    env = make_env(1)
    env.store_stock[:] = 10_000
    info = env.step()
    assert info["unmet"] == 0 and info["stockout"] == 0.0
    assert env.summary()["fill_rate"] == 1.0


def test_stockout_cost_uses_per_product_penalty(make_env):
    env = make_env(1, penalty_multiplier=2.0)
    env.store_stock[:] = 0
    env.wh_stock[:] = 0
    info = env.step()
    expected = float(np.sum(2.0 * np.array([p.stockout_penalty for p in cfg_products()])
                            * env._demand[0].sum(axis=0)))
    assert info["stockout"] == pytest.approx(expected)


def cfg_products():
    from src.models import default_products
    return default_products()


# --------------------------------------------------------------------------
# Orders, shipments and cost bookkeeping
# --------------------------------------------------------------------------
def test_order_enters_pipeline_and_arrives_after_lead_time(make_env):
    env = make_env(1)
    p, qty = 0, 50
    lead = int(env.lead[p])
    wh_before = int(env.wh_stock[p])

    info = env.step(orders={p: qty})
    assert info["orders"] == {p: qty}
    assert env.pipeline == [(lead, p, qty)]
    assert env.pipeline_qty(p) == qty
    assert int(env.wh_stock[p]) == wh_before            # nothing arrives on the day it is ordered

    for _ in range(lead):
        env.step()
    assert env.pipeline_qty(p) == 0
    assert int(env.wh_stock[p]) == wh_before + qty      # no shipments requested -> all stays in warehouse


def test_ordering_cost_is_fixed_fee_plus_unit_cost(make_env):
    env = make_env(1)
    info = env.step(orders={0: 30, 2: 20})
    expected = 2 * cfg.FIXED_ORDER_FEE + env.unit_cost[0] * 30 + env.unit_cost[2] * 20
    assert info["ordering"] == pytest.approx(expected)
    assert env.totals["num_orders"] == 2


def test_zero_order_has_no_fee(make_env):
    env = make_env(1)
    info = env.step(orders=np.zeros(env.num_products, dtype=int))
    assert info["ordering"] == 0.0 and info["orders"] == {}


def test_negative_orders_are_ignored(make_env):
    env = make_env(1)
    info = env.step(orders=[-10] * env.num_products)
    assert info["ordering"] == 0.0 and env.pipeline == []


def test_shipment_respects_truck_capacity(make_env):
    env = make_env(1, truck_capacity=40)
    env.wh_stock[:] = 1_000
    info = env.step(allocation=np.full((env.num_stores, env.num_products), 100))
    assert 0 < info["shipped"] <= 40


def test_shipment_respects_warehouse_stock(make_env):
    env = make_env(1, truck_capacity=10_000)
    wh_before = env.wh_stock.copy()
    info = env.step(allocation=np.full((env.num_stores, env.num_products), 10_000))
    assert info["shipped"] <= int(wh_before.sum())
    assert (env.wh_stock >= 0).all()


def test_no_allocation_means_no_shipment(make_env):
    env = make_env(1)
    store_before = env.store_stock.copy()
    info = env.step()
    assert info["shipped"] == 0
    assert (env.store_stock <= store_before).all()      # stores can only have sold stock


def test_holding_cost_is_charged_on_ending_stock(make_env):
    env = make_env(1)
    info = env.step()
    expected = float(np.sum(env.holding * (env.wh_stock + env.store_stock.sum(axis=0))))
    assert info["holding"] == pytest.approx(expected)


def test_day_cost_is_sum_of_components_and_totals_accumulate(make_env):
    env = make_env(11)
    rng = np.random.default_rng(3)
    while not env.done:
        env.step(*random_actions(env, rng))

    for h in env.history:
        assert h["cost"] == pytest.approx(h["ordering"] + h["holding"] + h["stockout"])

    s = env.summary()
    assert s["total_cost"] == pytest.approx(sum(h["cost"] for h in env.history))
    assert s["total_cost"] == pytest.approx(s["ordering_cost"] + s["holding_cost"] + s["stockout_cost"])
    assert 0.0 <= s["fill_rate"] <= 1.0
    assert s["fill_rate"] == pytest.approx(
        1 - s["lost_units"] / env.totals["demand_units"])
    assert len(env.history) == DAYS and env.done


def test_inventory_position_helpers(make_env):
    env = make_env(1)
    p = 1
    assert env.total_stock(p) == int(env.wh_stock[p] + env.store_stock[:, p].sum())
    env.step(orders={p: 60})
    assert env.pipeline_qty(p) == 60
    assert env.inventory_position(p) == env.total_stock(p) + 60
    assert env.pipeline_for(p) == ((int(env.lead[p]), 60),)
