"""Unit tests for the A* and Uniform-Cost planners (src/planners.py).

Run from the project root:   pytest tests/test_planners.py -v
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.models import PlanProblem, default_products  # noqa: E402
from src.planners import AStarPlanner, UniformCostPlanner  # noqa: E402

TOL = 1e-6

# (product index, start stock, pipeline, forecast demand per day)
CASES = {
    "rice_short":      (0, 60, (), (40, 40, 40, 40, 40)),
    "oil_low_stock":   (1, 20, (), (30, 30, 30, 30, 30)),
    "detergent_pipe":  (2, 30, ((2, 30),), (25, 25, 25, 25)),
    "tea_spike":       (3, 40, (), (20, 20, 50, 20, 20)),
    "snack_ample":     (4, 200, (), (15, 15, 15, 15, 15)),
}


def make_problem(case: str) -> PlanProblem:
    idx, stock, pipeline, demand = CASES[case]
    product = default_products()[idx]
    return PlanProblem(product=product, start_day=0, stock=stock,
                       pipeline=pipeline, demand=demand)


@pytest.fixture(params=list(CASES))
def problem(request) -> PlanProblem:
    return make_problem(request.param)


# --------------------------------------------------------------------------
# Heuristic: non-negative and admissible
# --------------------------------------------------------------------------
def test_heuristic_is_non_negative_along_optimal_path(problem):
    planner = AStarPlanner(cache=None)
    result = planner.solve(problem)
    assert result.success
    for state in result.path:
        assert planner.heuristic(state) >= 0.0


def test_heuristic_is_admissible_along_optimal_path(problem):
    """h(s) <= h*(s) for every state s on the optimal path.

    h*(s) is the true optimal cost-to-go, obtained by solving the sub-problem
    that starts in s with Uniform-Cost Search (h = 0, hence exact).
    """
    root = AStarPlanner(cache=None).solve(problem)
    assert root.success and root.path

    for state in root.path:
        sub = PlanProblem(product=problem.product, start_day=state.day,
                          stock=state.stock, pipeline=state.pipeline,
                          demand=problem.demand[state.day - problem.start_day:])
        astar = AStarPlanner(cache=None)
        astar.prepare(sub)
        h = astar.heuristic(sub.start_state)

        h_star = UniformCostPlanner(cache=None).solve(sub).cost

        assert h >= 0.0
        assert h <= h_star + TOL, f"h={h} overestimates h*={h_star} at {state}"


def test_heuristic_at_start_never_exceeds_optimal_cost(problem):
    planner = AStarPlanner(cache=None)
    result = planner.solve(problem)
    assert planner.heuristic(problem.start_state) <= result.cost + TOL


def test_heuristic_is_zero_at_goal_state(problem):
    planner = AStarPlanner(cache=None)
    result = planner.solve(problem)
    assert planner.heuristic(result.path[-1]) == pytest.approx(0.0)


# --------------------------------------------------------------------------
# A* vs UCS
# --------------------------------------------------------------------------
def test_astar_matches_ucs_cost_with_fewer_or_equal_nodes(problem):
    astar = AStarPlanner(cache=None).solve(problem)
    ucs = UniformCostPlanner(cache=None).solve(problem)

    assert astar.success and ucs.success
    assert astar.cost == pytest.approx(ucs.cost, abs=TOL)
    assert astar.nodes_expanded <= ucs.nodes_expanded


def test_astar_plan_cost_is_consistent_with_its_orders(problem):
    """Re-price the returned order plan by hand and compare with the reported cost."""
    result = AStarPlanner(cache=None).solve(problem)
    prod = problem.product

    stock = problem.stock
    arrivals = dict(problem.pipeline)           # arrival_day -> qty
    total = 0.0
    for day in range(problem.start_day, problem.end_day):
        stock += arrivals.pop(day, 0)
        demand = problem.demand[day - problem.start_day]
        served = min(stock, demand)
        stock -= served
        total += prod.holding_cost * stock + prod.stockout_penalty * (demand - served)
        q = result.orders.get(day, 0)
        if q > 0:
            total += 50.0 + prod.unit_cost * q
            arrivals[day + prod.lead_time] = arrivals.get(day + prod.lead_time, 0) + q

    assert total == pytest.approx(result.cost, abs=TOL)


def test_ucs_uses_zero_heuristic(problem):
    ucs = UniformCostPlanner(cache=None)
    ucs.prepare(problem)
    assert ucs.heuristic(problem.start_state) == 0.0
